package com.internetv2ray.vpn.gen.util.decryption;

public interface De1 {
    String decryptString(String string, int key);
}
