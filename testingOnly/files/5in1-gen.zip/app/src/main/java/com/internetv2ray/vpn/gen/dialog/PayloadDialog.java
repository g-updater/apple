package com.internetv2ray.vpn.gen.dialog;

import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;

import com.internetv2ray.vpn.gen.R;
import com.internetv2ray.vpn.gen.adapter.pAdapter;
import com.internetv2ray.vpn.gen.listener.SpinnerListener;
import com.internetv2ray.vpn.gen.util.FileUtil;
import com.internetv2ray.vpn.gen.util.gen;
import com.google.android.material.textfield.TextInputLayout;

import org.json.JSONObject;

import java.util.ArrayList;

public class PayloadDialog {

    private AlertDialog a;
    private Context c;
    private RadioGroup server_type;
    private Spinner pLogo, proto_spin;
    private CheckBox ckUseDefProxy, isReplace;
    private Button btnPayloadGen;
    private View v;
    private EditText etNetworkName, etNetworkPayload, etNetworkInfo, etSquidProxy, etSquidPort, etNetworkFrontQuery, etNetworkBackQuery;
    private boolean isAdd = true;

    public PayloadDialog(Context c) {
        a = new AlertDialog.Builder(c).create();
        a.setTitle("Add Payload");
        a.setCancelable(false);
        this.c = c;
    }

    private String mServerType() {
        if (server_type.getCheckedRadioButtonId() == R.id.cf_radio) {
            return "cf";
        }
        if (server_type.getCheckedRadioButtonId() == R.id.ws_radio) {
            return "ws";
        }
        return "http";
    }

    public void add() {
        isAdd = true;
        v = LayoutInflater.from(c).inflate(R.layout.dialog_add_payload, null);
        pLogo = v.findViewById(R.id.pLogo);
        proto_spin = v.findViewById(R.id.proto_spin);
        server_type = v.findViewById(R.id.server_type);
        etNetworkName = v.findViewById(R.id.etNetworkName);
        etNetworkPayload = v.findViewById(R.id.etNetworkPayload);
        etNetworkInfo = v.findViewById(R.id.etNetworkInfo);
        ckUseDefProxy = v.findViewById(R.id.ckUseDefProxy);
        etSquidProxy = v.findViewById(R.id.etSquidProxy);
        etSquidPort = v.findViewById(R.id.etSquidPort);
        etNetworkFrontQuery = v.findViewById(R.id.etNetworkFrontQuery);
        etNetworkBackQuery = v.findViewById(R.id.etNetworkBackQuery);
        btnPayloadGen = v.findViewById(R.id.btnPayloadGen);
        isReplace = v.findViewById(R.id.isReplace);
        ckUseDefProxy.setChecked(true);
        etSquidProxy.setEnabled(false);
        etSquidPort.setEnabled(false);
        server_type.check(R.id.cf_radio);
        proto_spin.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position == 0) {
                    ((TextInputLayout) v.findViewById(R.id.etNetworkPayloadInput)).setHint("Payload");
                    v.findViewById(R.id.excluded_udp_layout).setVisibility(View.VISIBLE);
                    v.findViewById(R.id.radio_type).setVisibility(View.VISIBLE);
                    btnPayloadGen.setVisibility(View.VISIBLE);
                } else if (position == 1) {
                    ((TextInputLayout) v.findViewById(R.id.etNetworkPayloadInput)).setHint("Config.json");
                    v.findViewById(R.id.excluded_udp_layout).setVisibility(View.GONE);
                    v.findViewById(R.id.radio_type).setVisibility(View.VISIBLE);
                    btnPayloadGen.setVisibility(View.VISIBLE);
                } else if (position == 2) {
                    ((TextInputLayout) v.findViewById(R.id.etNetworkPayloadInput)).setHint("DNS Address");
                    v.findViewById(R.id.excluded_udp_layout).setVisibility(View.GONE);
                    v.findViewById(R.id.radio_type).setVisibility(View.GONE);
                    btnPayloadGen.setVisibility(View.GONE);
                } else if (position == 3) {
                    //o((TextInputLayout) v.findViewById(R.id.etNetworkPayloadInput)).setHint("V2ray Payload");
                    v.findViewById(R.id.etNetworkPayloadInput).setVisibility(View.GONE);
                    v.findViewById(R.id.excluded_udp_layout).setVisibility(View.GONE);
                    v.findViewById(R.id.radio_type).setVisibility(View.GONE);
                    btnPayloadGen.setVisibility(View.GONE);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
        ckUseDefProxy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View p1) {
                if (ckUseDefProxy.isChecked()) {
                    etSquidProxy.setText("[Default]");
                    etSquidProxy.setEnabled(false);
                    etSquidPort.setEnabled(false);
                } else {
                    etSquidProxy.setText("");
                    etSquidProxy.setEnabled(true);
                    etSquidPort.setEnabled(true);
                }
            }
        });
        btnPayloadGen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View p1) {
                if (proto_spin.getSelectedItemPosition() == 0) {
                    gen pg = new gen(c);
                    pg.setCancelListener("Close", null);
                    pg.setGenerateListener("Generate", new gen.OnGenerateListener() {
                        @Override
                        public void onGenerate(String payloadGenerated) {
                            etNetworkPayload.setText(payloadGenerated);
                        }
                    });
                    pg.show();
                } else {
                    AlertDialog.Builder u = new AlertDialog.Builder(c);
                    View view = LayoutInflater.from(c).inflate(R.layout.dialog_udp_maker, null);
                    //  final EditText etServerIP = view.findViewById(R.id.etServerIP);
                    final EditText etServerObfs = view.findViewById(R.id.etServerObfs);
                    final EditText etServerUpMBPS = view.findViewById(R.id.etServerUpMBPS);
                    final EditText etServerDownMBPS = view.findViewById(R.id.etServerDownMBPS);
                    final EditText etServerRWConn = view.findViewById(R.id.etServerRWConn);
                    final EditText etServerRW = view.findViewById(R.id.etServerRW);
                    u.setNegativeButton("Cancel", null);
                    u.setPositiveButton("Generate", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface p1, int p2) {
                            JSONObject js = new JSONObject();
                            try {
                                //   js.put("server",etServerIP.getText().toString()+":10000-50000");
                                js.put("obfs", etServerObfs.getText().toString());
                                //     js.put("auth_str","auth_xxx");
                                js.put("up_mbps", Integer.parseInt(etServerUpMBPS.getText().toString()));
                                js.put("down_mbps", Integer.parseInt(etServerDownMBPS.getText().toString()));
                                js.put("retry", 3);
                                js.put("retry_interval", 1);
                                js.put("socks5", new JSONObject().put("listen", "127.0.0.1:1080"));
                                js.put("http", new JSONObject().put("listen", "127.0.0.1:8989"));
                                js.put("insecure", true);
                                js.put("ca", "");
                                js.put("recv_window_conn", Integer.parseInt(etServerRWConn.getText().toString()));
                                js.put("recv_window", Integer.parseInt(etServerRW.getText().toString()));
                                JSONObject jsonObj = new JSONObject(js.toString());
                                String finalJson = jsonObj.toString(2);
                                etNetworkPayload.setText(finalJson);
                            } catch (Exception e) {
                                Toast.makeText(c, e.getMessage(), Toast.LENGTH_LONG).show();
                            }
                        }
                    });
                    u.setTitle("UDP Generator");
                    u.setView(view);
                    u.create().show();
                }
            }
        });
        try {
            String[] list = c.getAssets().list("networks");
            ArrayList<String> plg = new ArrayList();
            for (int i = 0; i < list.length; i++) {
                plg.add(list[i].replace("icon_", "").replace(".png", ""));
            }
            pLogo.setAdapter(new pAdapter(c, plg));
        } catch (Exception e) {
            Toast.makeText(c, e.getMessage(), Toast.LENGTH_LONG).show();
        }

        a.setView(v);
    }

    public void edit(JSONObject json) {
        isAdd = false;
        v = LayoutInflater.from(c).inflate(R.layout.dialog_add_payload, null);
        pLogo = v.findViewById(R.id.pLogo);
        proto_spin = v.findViewById(R.id.proto_spin);
        server_type = v.findViewById(R.id.server_type);
        etNetworkName = v.findViewById(R.id.etNetworkName);
        etNetworkPayload = v.findViewById(R.id.etNetworkPayload);
        etNetworkInfo = v.findViewById(R.id.etNetworkInfo);
        ckUseDefProxy = v.findViewById(R.id.ckUseDefProxy);
        etSquidProxy = v.findViewById(R.id.etSquidProxy);
        etSquidPort = v.findViewById(R.id.etSquidPort);
        etNetworkFrontQuery = v.findViewById(R.id.etNetworkFrontQuery);
        etNetworkBackQuery = v.findViewById(R.id.etNetworkBackQuery);
        btnPayloadGen = v.findViewById(R.id.btnPayloadGen);
        isReplace = v.findViewById(R.id.isReplace);

        proto_spin.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position == 0) {
                    ((TextInputLayout) v.findViewById(R.id.etNetworkPayloadInput)).setHint("Payload");
                    v.findViewById(R.id.excluded_udp_layout).setVisibility(View.VISIBLE);
                    v.findViewById(R.id.radio_type).setVisibility(View.VISIBLE);
                    btnPayloadGen.setVisibility(View.VISIBLE);
                } else if (position == 1) {
                    ((TextInputLayout) v.findViewById(R.id.etNetworkPayloadInput)).setHint("Config.json");
                    v.findViewById(R.id.excluded_udp_layout).setVisibility(View.GONE);
                    v.findViewById(R.id.radio_type).setVisibility(View.VISIBLE);
                    btnPayloadGen.setVisibility(View.VISIBLE);
                } else if (position == 2) {
                    ((TextInputLayout) v.findViewById(R.id.etNetworkPayloadInput)).setHint("DNS Address");
                    v.findViewById(R.id.excluded_udp_layout).setVisibility(View.GONE);
                    v.findViewById(R.id.radio_type).setVisibility(View.GONE);
                    btnPayloadGen.setVisibility(View.GONE);
                }


                if (position==6) {
                    position = proto_spin.getSelectedItemPosition();
                    position=3;
                  }else if (position == 3) {

                    v.findViewById(R.id.etNetworkPayloadInput).setVisibility(View.GONE);
                    v.findViewById(R.id.excluded_udp_layout).setVisibility(View.GONE);
                    v.findViewById(R.id.radio_type).setVisibility(View.GONE);
                    btnPayloadGen.setVisibility(View.GONE);
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
        ckUseDefProxy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View p1) {
                if (ckUseDefProxy.isChecked()) {
                    etSquidProxy.setText("[Default]");
                    etSquidProxy.setEnabled(false);
                    etSquidPort.setEnabled(false);
                } else {
                    etSquidProxy.setText("");
                    etSquidProxy.setEnabled(true);
                    etSquidPort.setEnabled(true);
                }
            }
        });
        btnPayloadGen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View p1) {
                if (proto_spin.getSelectedItemPosition() == 0) {
                    gen pg = new gen(c);
                    pg.setGenerateListener("Generate", new gen.OnGenerateListener() {
                        @Override
                        public void onGenerate(String payloadGenerated) {
                            etNetworkPayload.setText(payloadGenerated);
                        }
                    });
                    pg.show();
                } else {
                    AlertDialog.Builder u = new AlertDialog.Builder(c);
                    View view = LayoutInflater.from(c).inflate(R.layout.dialog_udp_maker, null);
                    //   final EditText etServerIP = view.findViewById(R.id.etServerIP);
                    final EditText etServerObfs = view.findViewById(R.id.etServerObfs);
                    final EditText etServerUpMBPS = view.findViewById(R.id.etServerUpMBPS);
                    final EditText etServerDownMBPS = view.findViewById(R.id.etServerDownMBPS);
                    final EditText etServerRWConn = view.findViewById(R.id.etServerRWConn);
                    final EditText etServerRW = view.findViewById(R.id.etServerRW);
                    u.setNegativeButton("Cancel", null);
                    u.setPositiveButton("Generate", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface p1, int p2) {
                            JSONObject js = new JSONObject();
                            try {
                                //   js.put("server",etServerIP.getText().toString()+":10000-50000");
                                js.put("obfs", etServerObfs.getText().toString());
                                //     js.put("auth_str","auth_xxx");
                                js.put("up_mbps", Integer.parseInt(etServerUpMBPS.getText().toString()));
                                js.put("down_mbps", Integer.parseInt(etServerDownMBPS.getText().toString()));
                                js.put("retry", 3);
                                js.put("retry_interval", 1);
                                js.put("socks5", new JSONObject().put("listen", "127.0.0.1:1080"));
                                js.put("http", new JSONObject().put("listen", "127.0.0.1:8989"));
                                js.put("insecure", true);
                                js.put("ca", "");
                                js.put("recv_window_conn", Integer.parseInt(etServerRWConn.getText().toString()));
                                js.put("recv_window", Integer.parseInt(etServerRW.getText().toString()));
                                JSONObject jsonObj = new JSONObject(js.toString());
                                String finalJson = jsonObj.toString(2);
                                etNetworkPayload.setText(finalJson);
                            } catch (Exception e) {
                                Toast.makeText(c, e.getMessage(), Toast.LENGTH_LONG).show();
                            }
                        }
                    });
                    u.setTitle("UDP Generator");
                    u.setView(view);
                    u.create().show();
                }
            }
        });
        try {
            String[] list = c.getAssets().list("networks");
            ArrayList<String> plg = new ArrayList();
            for (int i = 0; i < list.length; i++) {
                plg.add(list[i].replace("icon_", "").replace(".png", ""));
            }
            pLogo.setAdapter(new pAdapter(c, plg));
        } catch (Exception e) {
            Toast.makeText(c, e.getMessage(), Toast.LENGTH_LONG).show();
        }
        try {
            String[] list = c.getAssets().list("networks");
            for (int i = 0; i < list.length; i++) {
                if (list[i].replace("icon_", "").replace(".png", "").equals(json.getString("FLAG"))) {
                    pLogo.setSelection(i);
                }
            }
            proto_spin.setSelection(json.getInt("proto_spin"));
            etNetworkName.setText(json.getString("Name"));
            etNetworkPayload.setText(FileUtil.showJs(c, json.getString("NetworkPayload")));
            etNetworkInfo.setText(json.getString("Info"));
            ckUseDefProxy.setChecked(json.getBoolean("UseDefProxy"));
            isReplace.setChecked(json.has("AutoReplace") ? json.getBoolean("AutoReplace") : false);
            etSquidPort.setText(json.getString("SquidPort"));
            etNetworkFrontQuery.setText(FileUtil.showJs(c, json.getString("NetworkFrontQuery")));
            etNetworkBackQuery.setText(FileUtil.showJs(c, json.getString("NetworkBackQuery")));
            if (json.getString("server_type").equals("cf")) {
                server_type.check(R.id.cf_radio);
            }
            if (json.getString("server_type").equals("ws")) {
                server_type.check(R.id.ws_radio);
            }
            if (json.getString("server_type").equals("http")) {
                server_type.check(R.id.http_radio);
            }
            if (json.getBoolean("UseDefProxy")) {
                etSquidProxy.setText("[Default]");
                etSquidProxy.setEnabled(false);
                etSquidPort.setEnabled(false);
            } else {
                etSquidProxy.setText(FileUtil.showJs(c, json.getString("SquidProxy")));
                etSquidProxy.setEnabled(true);
                etSquidPort.setEnabled(true);
            }
        } catch (Exception e) {
            Toast.makeText(c, e.getMessage(), Toast.LENGTH_LONG).show();
        }
        a.setView(v);
    }

    public void onPayloadAdd(final SpinnerListener oca) {
        v.findViewById(R.id.cancel).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View p1) {
                a.dismiss();
            }
        });
        v.findViewById(R.id.save).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View p1) {
                JSONObject jo = new JSONObject();
                try {
                    int position1 = pLogo.getSelectedItemPosition();
                    int protoSpin = proto_spin.getSelectedItemPosition();
                    if (proto_spin.getSelectedItem().toString().equals("V2ray")) {
                        protoSpin = 6;
                    }
                    String[] list = c.getAssets().list("networks");
                    jo.put("FLAG", list[position1].replace("icon_", "").replace(".png", ""));
                    jo.put("proto_spin", protoSpin);
                    jo.put("server_type", mServerType());
                    jo.put("Name", etNetworkName.getText().toString());
                    jo.put("NetworkPayload", FileUtil.hideJs(c, etNetworkPayload.getText().toString()));
                    jo.put("Info", etNetworkInfo.getText().toString());
                    jo.put("UseDefProxy", ckUseDefProxy.isChecked());
                    jo.put("AutoReplace", isReplace.isChecked());
                    jo.put("SquidProxy", FileUtil.hideJs(c, etSquidProxy.getText().toString()));
                    jo.put("SquidPort", etSquidPort.getText().toString());
                    jo.put("NetworkFrontQuery", FileUtil.hideJs(c, etNetworkFrontQuery.getText().toString()));
                    jo.put("NetworkBackQuery", FileUtil.hideJs(c, etNetworkBackQuery.getText().toString()));
                    oca.onAdd(jo);
                    Toast.makeText(c, etNetworkName.getText().toString() + " add", Toast.LENGTH_SHORT).show();
                    if (!isAdd) a.dismiss();
                } catch (Exception e) {
                    Toast.makeText(c, e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public void init() {
        a.show();
    }
}
