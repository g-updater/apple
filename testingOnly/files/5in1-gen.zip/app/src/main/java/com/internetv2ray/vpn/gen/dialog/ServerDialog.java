package com.internetv2ray.vpn.gen.dialog;

import android.content.Context;
import android.content.DialogInterface;
import androidx.appcompat.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import com.internetv2ray.vpn.gen.R;
import com.internetv2ray.vpn.gen.adapter.SerAdapter;
import com.internetv2ray.vpn.gen.listener.SpinnerListener;
import org.json.JSONObject;
import com.internetv2ray.vpn.gen.util.FileUtil;
import java.util.ArrayList;
import android.widget.AdapterView;
import com.google.android.material.textfield.TextInputLayout;

public class ServerDialog {

    private AlertDialog a;
    private Context c;
    private EditText sName,etServerIP,etServerCloudFront,etServerHTTP,etTcpPort,etSSLPort,etUser,etPass,etCertificate, etProxyPort;
    private Spinner sFlag,category, serverType;
    private CheckBox ckUseLogin, ckMultiCert;
    private boolean isAdd = true;
    private View v;
    public ServerDialog(Context c) {
        a = new AlertDialog.Builder(c).create();
        a.setTitle("Add Server");
        a.setCancelable(false);
        this.c = c;
    }
    
    public void add() {
        isAdd = true;
        v = LayoutInflater.from(c).inflate(R.layout.dialog_add_server, null);
        sName = v.findViewById(R.id.etServerName);
        sName = v.findViewById(R.id.etServerName);
        sFlag = v.findViewById(R.id.flagspin);
        category = v.findViewById(R.id.categorySpinner);
        etServerIP = v.findViewById(R.id.etServerIP);
        etServerCloudFront = v.findViewById(R.id.etServerCloudFront);
        etServerHTTP = v.findViewById(R.id.etServerHTTP);
        etTcpPort = v.findViewById(R.id.etTcpPort);
        etSSLPort = v.findViewById(R.id.etSSLPort);
        etCertificate = v.findViewById(R.id.etCertificate);
        etProxyPort = v.findViewById(R.id.etProxyPort);
        etUser = v.findViewById(R.id.etUser);
        etPass = v.findViewById(R.id.etPass);
        ckUseLogin = v.findViewById(R.id.ckUseLogin);
        ckMultiCert = v.findViewById(R.id.ckMultiCert);
        try {
            String[] list = c.getAssets().list("flags");
            ArrayList<String> flg = new ArrayList();
            for (int i = 0; i < list.length; i++) {
                flg.add(list[i]);
            }
            sFlag.setAdapter(new SerAdapter(c,flg));
        } catch (Exception e) {
            Toast.makeText(c,e.getMessage(), Toast.LENGTH_LONG).show();
        }
        serverType = v.findViewById(R.id.server_sptype);
        serverType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    v.findViewById(R.id.etTcpPort_ly).setVisibility(View.VISIBLE);
                    v.findViewById(R.id.etSSLPort).setVisibility(View.VISIBLE);
                    ckMultiCert .setVisibility(View.GONE);
                    ((TextInputLayout)v.findViewById(R.id.etServerIP_ly)).setVisibility(View.VISIBLE);
                    v.findViewById(R.id.etCertificate_ly).setVisibility(View.GONE);
                    if (position==0 || position==1){
                        ((TextInputLayout)v.findViewById(R.id.etTcpPort_ly)).setHint(position==0?"TCP Port:UDP Port":"SSH Port:Dropbear");
                        ((TextInputLayout)v.findViewById(R.id.etServerIP_ly)).setHint("Server IP/Host (cf)");
                        ((TextInputLayout)v.findViewById(R.id.etServerCloudFront_ly)).setHint("Cloud Front DNS (ws)");
                        v.findViewById(R.id.http_ly).setVisibility(View.VISIBLE);
                        v.findViewById(R.id.etTcpPort_ly).setVisibility(View.VISIBLE);
                        v.findViewById(R.id.etSSLPort_ly).setVisibility(View.VISIBLE);
                        v.findViewById(R.id.etProxyPort_ly).setVisibility(View.VISIBLE);
                        if(position==0){
                            ckMultiCert .setVisibility(View.VISIBLE);
                            v.findViewById(R.id.etCertificate_ly).setVisibility(ckMultiCert.isChecked()?View.VISIBLE:View.GONE);
                        }
                    }else if (position==2){
                        ((TextInputLayout)v.findViewById(R.id.etServerIP_ly)).setHint("Server IP/Host (ServerName)");
                        ((TextInputLayout)v.findViewById(R.id.etServerCloudFront_ly)).setHint("Public Key");
                        v.findViewById(R.id.http_ly).setVisibility(View.GONE);
                    }else if (position==3){
                        ((TextInputLayout)v.findViewById(R.id.etServerIP_ly)).setVisibility(View.GONE);
                        ((TextInputLayout)v.findViewById(R.id.etServerCloudFront_ly)).setHint("v2ray Config");
                        v.findViewById(R.id.http_ly).setVisibility(View.GONE);
                    }
                    else if (position==4){
                        ((TextInputLayout)v.findViewById(R.id.etServerIP_ly)).setHint("Server IP/Host (cf)");
                        ((TextInputLayout)v.findViewById(R.id.etServerCloudFront_ly)).setHint("Cloud Front DNS (ws)");
                        v.findViewById(R.id.http_ly).setVisibility(View.VISIBLE);
                        v.findViewById(R.id.etTcpPort_ly).setVisibility(View.GONE);
                        v.findViewById(R.id.etSSLPort_ly).setVisibility(View.GONE);
                        v.findViewById(R.id.etProxyPort_ly).setVisibility(View.GONE);
                    }
                }
                @Override
                public void onNothingSelected(AdapterView<?> parent) {
                }
            });
        ckMultiCert.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View p1) {
                    if (ckMultiCert.isChecked()){
                        v.findViewById(R.id.etCertificate_ly).setVisibility(View.VISIBLE);
                    }else {
                        v.findViewById(R.id.etCertificate_ly).setVisibility(View.GONE);
                    }
                }
            });
        ckUseLogin.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View p1) {
                    if (ckUseLogin.isChecked()){
                        v.findViewById(R.id.Account_ly).setVisibility(View.VISIBLE);
                    }else {
                        v.findViewById(R.id.Account_ly).setVisibility(View.GONE);
                    }
                }
            });
        a.setView(v);
    }

    public void edit(JSONObject json) {
        isAdd = false;
        v=LayoutInflater.from(c).inflate(R.layout.dialog_add_server, null);
        sName = v.findViewById(R.id.etServerName);
        sFlag = v.findViewById(R.id.flagspin);
        category = v.findViewById(R.id.categorySpinner);
        etServerIP = v.findViewById(R.id.etServerIP);
        etServerCloudFront = v.findViewById(R.id.etServerCloudFront);
        etServerHTTP = v.findViewById(R.id.etServerHTTP);
        etTcpPort = v.findViewById(R.id.etTcpPort);
        etSSLPort = v.findViewById(R.id.etSSLPort);
        etCertificate = v.findViewById(R.id.etCertificate);
        etProxyPort = v.findViewById(R.id.etProxyPort);
        etUser = v.findViewById(R.id.etUser);
        etPass = v.findViewById(R.id.etPass);
        ckUseLogin = v.findViewById(R.id.ckUseLogin);
        ckMultiCert = v.findViewById(R.id.ckMultiCert);
        try {
            String[] list = c.getAssets().list("flags");
            ArrayList<String> flg = new ArrayList();
            for (int i = 0; i < list.length; i++) {
                flg.add(list[i]);
            }
            sFlag.setAdapter(new SerAdapter(c,flg));
        } catch (Exception e) {
            Toast.makeText(c,e.getMessage(), Toast.LENGTH_LONG).show();
        }
        serverType = v.findViewById(R.id.server_sptype);
        serverType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    v.findViewById(R.id.etTcpPort_ly).setVisibility(View.VISIBLE);
                    v.findViewById(R.id.etSSLPort).setVisibility(View.VISIBLE);
                    ckMultiCert .setVisibility(View.GONE);
                    ((TextInputLayout)v.findViewById(R.id.etServerIP_ly)).setVisibility(View.VISIBLE);
                    v.findViewById(R.id.etCertificate_ly).setVisibility(View.GONE);
                    if (position==0 || position==1){
                        ((TextInputLayout)v.findViewById(R.id.etTcpPort_ly)).setHint(position==0?"TCP Port:UDP Port":"SSH Port:Dropbear");
                        ((TextInputLayout)v.findViewById(R.id.etServerIP_ly)).setHint("Server IP/Host (cf)");
                        ((TextInputLayout)v.findViewById(R.id.etServerCloudFront_ly)).setHint("Cloud Front DNS (ws)");
                        v.findViewById(R.id.http_ly).setVisibility(View.VISIBLE);
                        v.findViewById(R.id.etTcpPort_ly).setVisibility(View.VISIBLE);
                        v.findViewById(R.id.etSSLPort_ly).setVisibility(View.VISIBLE);
                        v.findViewById(R.id.etProxyPort_ly).setVisibility(View.VISIBLE);
                        if(position==0){
                            ckMultiCert .setVisibility(View.VISIBLE);
                            v.findViewById(R.id.etCertificate_ly).setVisibility(ckMultiCert.isChecked()?View.VISIBLE:View.GONE);
                        }
                    }else if (position==2){
                        ((TextInputLayout)v.findViewById(R.id.etServerIP_ly)).setHint("Server IP/Host (ServerName)");
                        ((TextInputLayout)v.findViewById(R.id.etServerCloudFront_ly)).setHint("Public Key");
                        v.findViewById(R.id.http_ly).setVisibility(View.GONE);
                    }else if (position==3){
                        ((TextInputLayout)v.findViewById(R.id.etServerIP_ly)).setVisibility(View.GONE);
                        ((TextInputLayout)v.findViewById(R.id.etServerCloudFront_ly)).setHint("v2ray Config");
                        v.findViewById(R.id.http_ly).setVisibility(View.GONE);
                    }
                    else if (position==4){
                        ((TextInputLayout)v.findViewById(R.id.etServerIP_ly)).setHint("Server IP/Host (cf)");
                        ((TextInputLayout)v.findViewById(R.id.etServerCloudFront_ly)).setHint("Cloud Front DNS (ws)");
                        v.findViewById(R.id.http_ly).setVisibility(View.VISIBLE);
                        v.findViewById(R.id.etTcpPort_ly).setVisibility(View.GONE);
                        v.findViewById(R.id.etSSLPort_ly).setVisibility(View.GONE);
                        v.findViewById(R.id.etProxyPort_ly).setVisibility(View.GONE);
                    }
                }
                @Override
                public void onNothingSelected(AdapterView<?> parent) {
                }
            });
        ckMultiCert.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View p1) {
                    if (ckMultiCert.isChecked()){
                        v.findViewById(R.id.etCertificate_ly).setVisibility(View.VISIBLE);
                    }else {
                        v.findViewById(R.id.etCertificate_ly).setVisibility(View.GONE);
                    }
                }
            });
        ckUseLogin.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View p1) {
                    if (ckUseLogin.isChecked()){
                        v.findViewById(R.id.Account_ly).setVisibility(View.VISIBLE);
                    }else {
                        v.findViewById(R.id.Account_ly).setVisibility(View.GONE);
                    }
                }
            });
        try {
            sName.setText(json.getString("Name"));
            etServerIP.setText(FileUtil.showJs(c,json.getString("ServerIP")));
            etServerCloudFront.setText(FileUtil.showJs(c,json.getString("ServerCloudFront")));
            etServerHTTP.setText(FileUtil.showJs(c,json.getString("ServerHTTP")));
            etTcpPort.setText(json.getString("TcpPort"));
            etSSLPort.setText(json.getString("SSLPort"));
            etProxyPort.setText(json.has("ProxyPort")?json.getString("ProxyPort"):"");
            etCertificate.setText(json.has("ovpnCertificate")?FileUtil.showJs(c,json.getString("ovpnCertificate")):"");
            ckMultiCert.setChecked(json.has("MultiCert")?json.getBoolean("MultiCert"):false);
            ckUseLogin.setChecked(json.getBoolean("AutoLogIn"));
            etUser.setText(json.getBoolean("AutoLogIn")?FileUtil.showJs(c,json.getString("Username")):"");
            etPass.setText(json.getBoolean("AutoLogIn")?FileUtil.showJs(c,json.getString("Password")):"");
            String[] list = c.getAssets().list("flags");
            for (int i = 0; i < list.length; i++) {
                if (list[i].replace("flag_","").replace(".png","").equals(json.getString("FLAG"))) {
                    sFlag.setSelection(i);
                }
            }
            serverType.setSelection(json.getInt("serverType"));
            category.setSelection(json.getInt("Category"));
            v.findViewById(R.id.Account_ly).setVisibility(json.getBoolean("AutoLogIn")?View.VISIBLE:View.GONE);
            if(json.getInt("serverType")==0&&json.has("MultiCert")){
                v.findViewById(R.id.etCertificate_ly).setVisibility(json.getBoolean("MultiCert")?View.VISIBLE:View.GONE);
            }
        } catch (Exception e) {}
        a.setView(v);
    }
    public void onServerAdd(final SpinnerListener oca) {
        v.findViewById(R.id.cancel).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View p1) {
                    a.dismiss();
                }
            });
        v.findViewById(R.id.save).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View p1) {
                    JSONObject jo=new JSONObject();
                    try {
                        int position2 = sFlag.getSelectedItemPosition();
                        String[] list = c.getAssets().list("flags");
                        boolean x = serverType.getSelectedItemPosition()==0;
                        boolean y = x?ckMultiCert.isChecked():false;
                        jo.put("Name", sName.getText().toString());
                        jo.put("serverType", serverType.getSelectedItemPosition());
                        jo.put("FLAG", list[position2].replace("flag_","").replace(".png",""));
                        jo.put("Category", category.getSelectedItemPosition());
                        jo.put("ServerIP", FileUtil.hideJs(c,etServerIP.getText().toString()));
                        jo.put("ServerCloudFront", FileUtil.hideJs(c,etServerCloudFront.getText().toString()));
                        jo.put("ServerHTTP", FileUtil.hideJs(c,etServerHTTP.getText().toString()));
                        jo.put("TcpPort", etTcpPort.getText().toString());
                        jo.put("SSLPort", etSSLPort.getText().toString());
                        jo.put("ProxyPort", etProxyPort.getText().toString());
                        jo.put("AutoLogIn", ckUseLogin.isChecked());
                        jo.put("Username", ckUseLogin.isChecked()?FileUtil.hideJs(c,etUser.getText().toString()):"");
                        jo.put("Password", ckUseLogin.isChecked()?FileUtil.hideJs(c,etPass.getText().toString()):"");
                        jo.put("Password", ckUseLogin.isChecked()?FileUtil.hideJs(c,etPass.getText().toString()):"");
                        jo.put("MultiCert", y);
                        jo.put("ovpnCertificate", y?FileUtil.hideJs(c,etCertificate.getText().toString()):"");
                        oca.onAdd(jo);
                        Toast.makeText(c, sName.getText().toString()+" add", Toast.LENGTH_SHORT).show();
                        if(!isAdd)a.dismiss();
                    } catch (Exception e) {
                        Toast.makeText(c, e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            });
    }

    public void init() {
        a.show();
    }
}
