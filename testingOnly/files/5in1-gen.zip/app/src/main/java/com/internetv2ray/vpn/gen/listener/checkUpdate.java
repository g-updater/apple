package com.internetv2ray.vpn.gen.listener;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.URL;

public class checkUpdate extends AsyncTask<String, String, String> {

    @SuppressLint("StaticFieldLeak")
    private Context context;
    private Listener listener;
    private ProgressDialog pd;
    private final String mUrl;
    public interface Listener {
        void onCompleted(String config);
        void onError(String ex);
    }

    public checkUpdate(Context context, String _mUrl, Listener listener) {
        this.context = context;
        this.mUrl = _mUrl;
        this.listener = listener;
    }

    @Override
    protected void onPreExecute() {
        pd = new ProgressDialog(context);
        pd.setMessage("Checking Please Wait...");
        pd.show();
    }

    public void start(){
        execute(mUrl);
    }

    @Override
    protected String doInBackground(String[] p1) {
        try {
            URL mURL = new URL(p1[0]);
            HttpURLConnection con = (HttpURLConnection)mURL.openConnection();
            con.connect();
            StringBuilder sb = new StringBuilder();
            Reader reader = new BufferedReader(new InputStreamReader(con.getInputStream()));
            char[] buf = new char[1024];
            while (true) {
                int read = reader.read(buf);
                if (read <= 0) {
                    break;
                }
                sb.append(buf, 0, read);
            }
            return sb.toString();
        } catch (Exception e) {
            return "error: "+e.getMessage();
        }
    }

    @Override
    protected void onCancelled() {
        super.onCancelled();
        pd.dismiss();
    }

    @Override
    protected void onPostExecute(String result) {
        if (result.startsWith("error")) {
            listener.onError(result);
        } else
            listener.onCompleted(result);
        pd.dismiss();
    }

}

