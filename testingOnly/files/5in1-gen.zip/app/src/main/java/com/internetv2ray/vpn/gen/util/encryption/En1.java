package com.internetv2ray.vpn.gen.util.encryption;

public interface En1 {
    String encryptString(String string, int key);
}
