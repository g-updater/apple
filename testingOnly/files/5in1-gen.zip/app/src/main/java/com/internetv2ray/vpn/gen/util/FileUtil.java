package com.internetv2ray.vpn.gen.util;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.widget.Toast;
import androidx.core.content.ContextCompat;

import com.internetv2ray.vpn.gen.LauncherActivity;
import com.internetv2ray.vpn.gen.R;
import com.internetv2ray.vpn.gen.util.decryption.De;
import com.internetv2ray.vpn.gen.util.decryption.De2;
import com.internetv2ray.vpn.gen.util.encryption.En;
import com.internetv2ray.vpn.gen.util.encryption.En2;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.net.ssl.HttpsURLConnection;

public class FileUtil {


    public static boolean isStorageReadable(Context c) {
        int result = ContextCompat.checkSelfPermission(c, Manifest.permission.WRITE_EXTERNAL_STORAGE);
        if (result == PackageManager.PERMISSION_GRANTED){
            return true;
        }
        return false;
    }

    private static final int DELTA = 772515655;
    private static int MX(int sum, int y, int z, int p, int e, int[] k) {
        return (z >>> 5 ^ y << 2) + (y >>> 3 ^ z << 4) ^ (sum ^ y) + (k[p & 3 ^ e] ^ z);
    }
    public static String readFromAsset(Context c){
        String hServer = null;
        try {
            File file = new File(c.getFilesDir(),"default.hs");
            StringBuilder b = new StringBuilder();
            Reader reader = null;
            char[] buff = new char[1024];
            if (file.exists()) {
                reader = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
            } else {
                reader = new BufferedReader(new InputStreamReader(c.getAssets().open("default.hs")));
            }
            while (true) {
                int read = reader.read(buff,0,buff.length);
                if (read <= 0) {
                    break;
                }
                b.append(buff,0,read);
            }
            return hServer = b.toString();

        } catch (Exception e) {
            Toast.makeText(c,e.getMessage(), Toast.LENGTH_LONG).show();
        }
        return hServer;
    }

    @SuppressLint("NewApi")
    @SuppressWarnings("deprecation")
    public static void copyToClipboard(Context context, String text){
        try{
            int sdk = android.os.Build.VERSION.SDK_INT;
            if (sdk < android.os.Build.VERSION_CODES.HONEYCOMB) {
                android.text.ClipboardManager clipboard = (android.text.ClipboardManager) context.getSystemService(context.CLIPBOARD_SERVICE);clipboard.setText(text);
            }else {
                android.content.ClipboardManager clipboard = (android.content.ClipboardManager) context.getSystemService(context.CLIPBOARD_SERVICE);
                android.content.ClipData clip = android.content.ClipData.newPlainText("Message", text);
                clipboard.setPrimaryClip(clip);
            }
        }catch (Exception e){
            Toast.makeText(context,e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    public static void exitAll(Activity activity) {
        if (Build.VERSION.SDK_INT >= 16) {
            activity.finishAffinity();
        }
        System.exit(0);
    }

    public static String save(Context c,String title,String content,int p)
    {
        File dir=new File(Environment.getExternalStorageDirectory().getAbsolutePath()+ "/DexterGenAio");
        dir.mkdirs();
        File file=new File(dir,title+".hs");
        try
        {
            OutputStream os=new FileOutputStream(file);
            os.write(content.getBytes());
            os.flush();
            os.close();
            if(p==1)Toast.makeText(c,"File save at "+dir.toString()+"/"+title+".hs", Toast.LENGTH_LONG).show();
            return dir.toString()+"/"+title+".hs";
        }
        catch (IOException e)
        {
            Toast.makeText(c,e.getMessage(), Toast.LENGTH_LONG).show();
        }
        return "";
    }

    public static void setPass(String pass,Context c){
        SharedPreferences mPref = c.getSharedPreferences("mKEYGEN", c.MODE_PRIVATE);
        mPref.edit().putString("mPass", pass).apply();
    }

    public static String getPass(Context c) {
        StringBuffer buf = new StringBuffer();
        SharedPreferences mPref = c.getSharedPreferences("mKEYGEN", c.MODE_PRIVATE);
        String str = ToHex(mPref.getString("mPass", ""));
        buf.append(str.substring(0, 4));
        return buf.toString();
    }

    public static String showJs(Context c,String msg){
        try {
            String _de = decryptBase64StringToString(msg, getPass(c));
            return _De(c, _de);
        }catch (Exception e){
            Toast.makeText(c,e.getMessage(), Toast.LENGTH_LONG).show();
        }
        return "error!";
    }

    public static String hideJs(Context c,String msg){
        try {
            String _en = _En(c, msg);
            return encryptToBase64String(_en, getPass(c));
        }catch (Exception e){
            Toast.makeText(c,e.getMessage(), Toast.LENGTH_LONG).show();
        }
        return "error!";
    }

    private static String _De(Context c,String msg)throws Exception{
        De de = new De();
        de.setMethod(new De2());
        int p = Integer.parseInt(getPass(c));
        String de1 = de.decryptString(msg, p);
        return de.decryptString(de1, p);
    }
    private static String _En(Context c,String msg)throws Exception{
        En encrypter = new En();
        encrypter.setMethod(new En2());
        int p = Integer.parseInt(getPass(c));
        String e1 = encrypter.encryptString(msg,p);
        return encrypter.encryptString(e1,p);
    }

    public static String readTextFile(File f){
        StringBuilder text = new StringBuilder();
        try {
            BufferedReader br = new BufferedReader(new FileReader(f));
            String st;
            while((st = br.readLine()) != null){
                text.append(st + "\n");
            }
            br.close();
            return text.toString();
        } catch(Exception e){
            e.printStackTrace();
        }
        return "";
    }
    public static String readTextUri(Context c, Uri uri){
        BufferedReader reader = null;
        StringBuilder builder = new StringBuilder();
        try {
            reader = new BufferedReader(new InputStreamReader(c.getContentResolver().openInputStream(uri)));
            String line = "";
            while ((line = reader.readLine()) != null) {
                builder.append(line);
                builder.append("\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (reader != null){
                try {
                    reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return builder.toString();
    }

    public static final byte[] encrypt(byte[] data, byte[] key) {
        if (data.length == 0) {
            return data;
        }
        return toByteArray(
            encrypt(toIntArray(data, true), toIntArray(fixKey(key), false)), false);
    }
    public static final byte[] encrypt(String data, byte[] key) {
        try {
            return encrypt(data.getBytes("UTF-8"), key);
        }
        catch (UnsupportedEncodingException e) {
            return null;
        }
    }
    public static final byte[] encrypt(byte[] data, String key) {
        try {
            return encrypt(data, key.getBytes("UTF-8"));
        }
        catch (UnsupportedEncodingException e) {
            return null;
        }
    }
    public static final byte[] encrypt(String data, String key) {
        try {
            return encrypt(data.getBytes("UTF-8"), key.getBytes("UTF-8"));
        }
        catch (UnsupportedEncodingException e) {
            return null;
        }

    }
    public static final String encryptToBase64String(byte[] data, byte[] key) {
        byte[] bytes = encrypt(data, key);
        if (bytes == null) return null;
        return TeaBase64.encode(bytes);
    }
    public static final String encryptToBase64String(String data, byte[] key) {
        byte[] bytes = encrypt(data, key);
        if (bytes == null) return null;
        return TeaBase64.encode(bytes);
    }
    public static final String encryptToBase64String(byte[] data, String key) {
        byte[] bytes = encrypt(data, key);
        if (bytes == null) return null;
        return TeaBase64.encode(bytes);
    }
    public static final String encryptToBase64String(String data, String key) {
        byte[] bytes = encrypt(data, key);
        if (bytes == null) return null;
        return TeaBase64.encode(bytes);
    }
    public static final byte[] decrypt(byte[] data, byte[] key) {
        if (data.length == 0) {
            return data;
        }
        return toByteArray(
            decrypt(toIntArray(data, false), toIntArray(fixKey(key), false)), true);
    }
    public static final byte[] decrypt(byte[] data, String key) {
        try {
            return decrypt(data, key.getBytes("UTF-8"));
        }
        catch (UnsupportedEncodingException e) {
            return null;
        }
    }
    public static final byte[] decryptBase64String(String data, byte[] key) {
        return decrypt(TeaBase64.decode(data), key);
    }
    public static final byte[] decryptBase64String(String data, String key) {
        return decrypt(TeaBase64.decode(data), key);
    }
    public static final String decryptToString(byte[] data, byte[] key) {
        try {
            byte[] bytes = decrypt(data, key);
            if (bytes == null) return null;
            return new String(bytes, "UTF-8");
        }
        catch (UnsupportedEncodingException ex) {
            return null;
        }
    }
    public static final String decryptToString(byte[] data, String key) {
        try {
            byte[] bytes = decrypt(data, key);
            if (bytes == null) return null;
            return new String(bytes, "UTF-8");
        }
        catch (UnsupportedEncodingException ex) {
            return null;
        }
    }
    public static final String decryptBase64StringToString(String data, byte[] key) {
        try {
            byte[] bytes = decrypt(TeaBase64.decode(data), key);
            if (bytes == null) return null;
            return new String(bytes, "UTF-8");
        }
        catch (UnsupportedEncodingException ex) {
            return null;
        }
    }
    public static final String decryptBase64StringToString(String data, String key) {
        try {
            byte[] bytes = decrypt(TeaBase64.decode(data), key);
            if (bytes == null) return null;
            return new String(bytes, "UTF-8");
        }
        catch (UnsupportedEncodingException ex) {
            return null;
        }
    }

    private static int[] encrypt(int[] v, int[] k) {
        int n = v.length - 1;
        if (n < 1) {
            return v;
        }
        int p, q = 6 + 52 / (n + 1);
        int z = v[n], y, sum = 0, e;
        while (q-- > 0) {
            sum = sum + DELTA;
            e = sum >>> 2 & 3;
            for (p = 0; p < n; p++) {
                y = v[p + 1];
                z = v[p] += MX(sum, y, z, p, e, k);
            }
            y = v[0];
            z = v[n] += MX(sum, y, z, p, e, k);
        }
        return v;
    }

    private static int[] decrypt(int[] v, int[] k) {
        int n = v.length - 1;
        if (n < 1) {
            return v;
        }
        int p, q = 6 + 52 / (n + 1);
        int z, y = v[0], sum = q * DELTA, e;
        while (sum != 0) {
            e = sum >>> 2 & 3;
            for (p = n; p > 0; p--) {
                z = v[p - 1];
                y = v[p] -= MX(sum, y, z, p, e, k);
            }
            z = v[n];
            y = v[0] -= MX(sum, y, z, p, e, k);
            sum = sum - DELTA;
        }
        return v;
    }

    private static byte[] fixKey(byte[] key) {
        if (key.length == 16) return key;
        byte[] fixedkey = new byte[16];
        if (key.length < 16) {
            System.arraycopy(key, 0, fixedkey, 0, key.length);
        }
        else {
            System.arraycopy(key, 0, fixedkey, 0, 16);
        }
        return fixedkey;
    }

    private static int[] toIntArray(byte[] data, boolean includeLength) {
        int n = (((data.length & 3) == 0)
            ? (data.length >>> 2)
            : ((data.length >>> 2) + 1));
        int[] result;


        if (includeLength) {
            result = new int[n + 1];
            result[n] = data.length;
        }
        else {
            result = new int[n];
        }
        n = data.length;
        for (int i = 0; i < n; ++i) {
            result[i >>> 2] |= (0x000000ff & data[i]) << ((i & 3) << 3);
        }
        return result;
    }


    private static byte[] toByteArray(int[] data, boolean includeLength) {
        int n = data.length << 2;
        if (includeLength) {
            int m = data[data.length - 1];
            n -= 4;
            if ((m < n - 3) || (m > n)) {
                return null;
            }
            n = m;
        }
        byte[] result = new byte[n];
        for (int i = 0; i < n; ++i) {
            result[i] = (byte) (data[i >>> 2] >>> ((i & 3) << 3));
        }
        return result;
    }
    public static String ToHex(String input) {
        if (input == null) throw new NullPointerException();
        return asHex(input.getBytes());
    }

    public static String tostring(String hex) {
        String digital = BED._a;
        char[] hex2char = hex.toCharArray();
        byte[] bytes = new byte[hex.length() / 2];
        int temp;
        for (int i = 0; i < bytes.length; i++) {
            temp = digital.indexOf(hex2char[2 * i]) * 16;
            temp += digital.indexOf(hex2char[2 * i + 1]);
            bytes[i] = (byte) (temp & 0xff);
        }
        return new String(bytes);
    }

    public static String asHex(byte[] bs) {
        char[] digital = BED._a.toCharArray();
        StringBuilder sb = new StringBuilder();
        int bit;
        for (byte b : bs) {
            bit = (b & 0x0f0) >> 4;
            sb.append(digital[bit]);
            bit = b & 0x0f;
            sb.append(digital[bit]);
        }
        return sb.toString();
    }
}
