package com.internetv2ray.vpn.gen;

import android.Manifest;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import com.internetv2ray.vpn.gen.adapter.HTTPSpinnerAdapter;
import com.internetv2ray.vpn.gen.adapter.ServerSpinnerAdapter;
import com.internetv2ray.vpn.gen.adapter.sslSpinnerAdapter;
import com.internetv2ray.vpn.gen.dialog.PayloadDialog;
import com.internetv2ray.vpn.gen.dialog.SSLDialog;
import com.internetv2ray.vpn.gen.dialog.ServerDialog;
import com.internetv2ray.vpn.gen.listener.checkUpdate;
import com.internetv2ray.vpn.gen.util.DataBaseHelper;
import com.internetv2ray.vpn.gen.util.FileUtil;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.snackbar.Snackbar;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Reader;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;

import javax.net.ssl.HttpsURLConnection;

public class MainActivity extends AppCompatActivity {
    private DrawerLayout drawerLayout;
    private ActionBarDrawerToggle dt;
    private NavigationView nv;
    public static final String UPDATE_ADAPTERS = "_UPDATE_SERVER_ADAPTER";
    final static int REQUEST_CODE = 01;
    final static int REQUEST_CODE2 = 02;
    private Spinner a, b, c;
    private TextView mLogs;
    private TextView mVersion;
    private View fn_lay, vs_lay, rn_lay;
    private TextView mFileName;
    private SharedPreferences sp;
    private Snackbar snackbar2;
    private Snackbar snackbar;
    private DataBaseHelper ServerData, HTTPData, SSLData;
    private int showEnDe = -1;

    public void saveJson() {
        if (isPermissionGranted(Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
            requestPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE, REQUEST_CODE);
        } else {

        }
    }

    public boolean isPermissionGranted(String permission) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            return checkSelfPermission(permission) != PackageManager.PERMISSION_GRANTED;
        } else {
            return ActivityCompat.checkSelfPermission(MainActivity.this, permission) != PackageManager.PERMISSION_GRANTED;
        }
    }

    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case REQUEST_CODE:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    if (snackbar != null) {
                        snackbar.dismiss();
                    }
                    if (snackbar2 != null) {
                        snackbar2.dismiss();
                    }
                } else {
                    snackbar = Snackbar.make(getWindow().getDecorView().findViewById(android.R.id.content), "Please Allow the permission", Snackbar.LENGTH_INDEFINITE);
                    snackbar.setAction("ALLOW", new View.OnClickListener(){

                        @Override
                        public void onClick(View p1) {
                            requestPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE, REQUEST_CODE);
                        }
                    });
                    snackbar.show();
                }
                return;
            case REQUEST_CODE2:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // setupImport();
                    if (snackbar2 != null) {
                        snackbar2.dismiss();
                    }
                    if (snackbar != null) {
                        snackbar.dismiss();
                    }
                } else {
                    snackbar2 = Snackbar.make(getWindow().getDecorView().findViewById(android.R.id.content), "Please Allow the permission", Snackbar.LENGTH_INDEFINITE);
                    snackbar2.setAction("ALLOW", new View.OnClickListener(){

                        @Override
                        public void onClick(View p1) {
                            requestPermission(Manifest.permission.READ_EXTERNAL_STORAGE, REQUEST_CODE2);
                        }
                    });
                    snackbar2.show();
                }
                return;
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    private void requestPermission(String permission , int code) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            requestPermissions(new String[]{permission}, code);
        } else {
            ActivityCompat.requestPermissions(MainActivity.this , new String[]{permission}, code);
        }
    }

    public static void updateMainViews(Context context) {
        Intent updateView = new Intent(UPDATE_ADAPTERS);
        LocalBroadcastManager.getInstance(context).sendBroadcast(updateView);
    }

    private BroadcastReceiver mActivityReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (action == null)
                return;
            if (action.equals(UPDATE_ADAPTERS) && !isFinishing()) {
                refreshALLAdapters();
                Toast.makeText(MainActivity.this, "ImportedJs Successfully", Toast.LENGTH_LONG).show();
            }
        }
    };

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public static void setStatusBarColor(Activity activity, int color) {
        activity.getWindow().setStatusBarColor(color);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Thread.setDefaultUncaughtExceptionHandler(new ExceptionHandler(this));
        setStatusBarColor(this, Color.parseColor("#151515"));
        setContentView(R.layout.home);
        drawerLayout = findViewById(R.id.drawer_layout);
        nv = findViewById(R.id.navigation);
        Toolbar toolbar_main = findViewById(R.id.toolbar_main);
        setSupportActionBar(toolbar_main);
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        dt = new ActionBarDrawerToggle(this, drawerLayout, toolbar_main, R.string.app_name, R.string.app_name);
        drawerLayout.addDrawerListener(dt);
        dt.syncState();
        ServerData = new DataBaseHelper(this, "ServerData");
        HTTPData = new DataBaseHelper(this, "HTTPData");
        SSLData = new DataBaseHelper(this, "SSLData");
        sp = getSharedPreferences("TKApplication", MODE_PRIVATE);
        a = findViewById(R.id.serverList);
        b = findViewById(R.id.payloadList);
        c = findViewById(R.id.sslList);
        fn_lay = findViewById(R.id.fn_lay);
        rn_lay = findViewById(R.id.rn_lay);
        vs_lay = findViewById(R.id.vs_lay);
        mFileName = findViewById(R.id.mFileName);
        mLogs =  findViewById(R.id.mLogs);
        mVersion = findViewById(R.id.mVersion);
        nv.setNavigationItemSelectedListener(menuItem -> {
            int id = menuItem.getItemId();
            switch (id) {
                case R.id.item1:
                    clear_warning(0);
                    drawerLayout.closeDrawers();
                    break;
                case R.id.item2:
                    clear_warning(1);
                    drawerLayout.closeDrawers();
                    break;
                case R.id.des:
                    en_de_text("", "");
                    drawerLayout.closeDrawers();
                    break;
                case R.id.item3:
                    JSONObject jsonObj;
                    try {
                        jsonObj = new JSONObject(ja().toString());
                    } catch (JSONException e) {
                        throw new RuntimeException(e);
                    }
                    try {
                        updateConfig(FileUtil.hideJs(MainActivity.this, jsonObj.toString(1)));
                    } catch (JSONException e) {
                        throw new RuntimeException(e);
                    }
                    drawerLayout.closeDrawers();
                    break;
                case R.id.item4:
                    setCERTIFICATE();
                    drawerLayout.closeDrawers();
                    break;
                case R.id.item5:
                    ExportOnline();
                    drawerLayout.closeDrawers();
                    break;
            }
            return false;
        });
        IntentFilter filter = new IntentFilter();
        filter.addAction(UPDATE_ADAPTERS);
        LocalBroadcastManager.getInstance(this).registerReceiver(mActivityReceiver, filter);
        refreshALLAdapters();
        toolbar_main.setOnClickListener(p1 -> {
            showEnDe++;
            if (showEnDe == 20) {
                showEnDe = 0;
                en_de_text("", "");

            }
        });
    }
    public void SaveFile(View view) {
        saveJson();
        final AlertDialog.Builder dialog = new AlertDialog.Builder(MainActivity.this);
        View v = LayoutInflater.from(MainActivity.this).inflate(R.layout.dialog_save, null);
        final EditText fName = v.findViewById(R.id.fName);
        final EditText cSupport = v.findViewById(R.id.cSupport);
        final EditText releaseNote = v.findViewById(R.id.releaseNote);
        final EditText cVereion = v.findViewById(R.id.cVereion);
        fName.setText(sp.getString("_FileName", ""));
        fName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String fn = fName.getText().toString().trim();
                sp.edit().putString("_FileName", fn).apply();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        cSupport.setText(sp.getString("_contactSupport", ""));
        cSupport.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String cs = cSupport.getText().toString().trim();
                sp.edit().putString("_contactSupport", cs).apply();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        releaseNote.setText(sp.getString("_ReleaseNotes", ""));
        releaseNote.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String rn = releaseNote.getText().toString().trim();
                sp.edit().putString("_ReleaseNotes", rn).apply();
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
        cVereion.setText(sp.getString("_Version", ""));
        cVereion.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String vs = cVereion.getText().toString().trim();
                sp.edit().putString("_Version", vs).apply();
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
        dialog.setView(v);
        dialog.setIcon(R.drawable.icon3);
        dialog.setTitle("Save File");
        dialog.setCancelable(true);
        dialog.setNeutralButton("Close", (p1, p2) -> {
            refreshALLAdapters();
            p1.dismiss();
        });
        dialog.setNegativeButton("Copy", (p1, p2) -> {
            if (fName.getText().toString().isEmpty()) {
                Toast.makeText(MainActivity.this, "Please set a file name!", Toast.LENGTH_LONG).show();
                fName.setError("Please set a file name!");
                return;
            }
            if (cVereion.getText().toString().isEmpty()) {
                Toast.makeText(MainActivity.this, "Please set a file version!", Toast.LENGTH_LONG).show();
                cVereion.setError("Please set a file version!");
                return;
            }
            try {
                String f = fName.getText().toString();
                JSONObject jsonObj = new JSONObject(ja().toString());
                FileUtil.copyToClipboard(MainActivity.this, FileUtil.hideJs(MainActivity.this, jsonObj.toString(1)));
                sp.edit().putString("_FileName", f).apply();
                sp.edit().putString("_Version", cVereion.getText().toString()).apply();
                refreshALLAdapters();
                Toast.makeText(MainActivity.this, "Copy To Clipboard", Toast.LENGTH_LONG).show();
            } catch (Exception e) {
                Toast.makeText(MainActivity.this, e.getMessage(), Toast.LENGTH_LONG).show();
            }
        });

        dialog.setPositiveButton("Save", (p1, p2) -> {
            String f = fName.getText().toString();

            if (fName.getText().toString().isEmpty()) {
                Toast.makeText(MainActivity.this, "Please set a file name!", Toast.LENGTH_LONG).show();
                fName.setError("Please set a file name!");
                return;
            }
            if (cVereion.getText().toString().isEmpty()) {
                Toast.makeText(MainActivity.this, "Please set a file version!", Toast.LENGTH_LONG).show();
                cVereion.setError("Please set a file version!");
                return;
            }
            try {
                JSONObject jsonObj = new JSONObject(Objects.requireNonNull(ja()).toString());
                String fn = FileUtil.save(MainActivity.this, f, FileUtil.hideJs(MainActivity.this, jsonObj.toString(1)), 1);
                sp.edit().putString("_FileName", f).apply();
                sp.edit().putString("fileFolder", fn).apply();
                sp.edit().putString("_Version", cVereion.getText().toString()).apply();
                refreshALLAdapters();
            } catch (Exception e) {
                Toast.makeText(MainActivity.this, e.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
        AlertDialog alertDialog = dialog.create();
        alertDialog.setCancelable(false);
        alertDialog.show();
    }


    private void updateConfig(String hideJs) {

        try {
            String getAPI = LauncherActivity.CONFIG_GET_API;
            String postAPI = LauncherActivity.CONFIG_POST_API;
            LinkedHashMap linkedHashMap = new LinkedHashMap();
            linkedHashMap.put("hash", getAPI.contains("json=") ? getAPI.split("json=")[1] : getAPI.split("json/")[1].split("\\.")[0]);
            linkedHashMap.put(postAPI.contains("edit.php") ? "data" : "code", hideJs);
            StringBuilder sb = new StringBuilder();
            for (Object entry : linkedHashMap.entrySet()) {
                if (sb.length() != 0) {
                    sb.append('&');
                }
                sb.append(URLEncoder.encode((String) ((Map.Entry) entry).getKey(), "UTF-8"));
                sb.append('=');
                sb.append(URLEncoder.encode(String.valueOf((String) ((Map.Entry) entry).getValue()), "UTF-8"));
            }
            byte[] bytes = sb.toString().getBytes("UTF-8");
            HttpsURLConnection httpsURLConnection = (HttpsURLConnection) new URL(postAPI).openConnection();
            httpsURLConnection.setInstanceFollowRedirects(false);
            httpsURLConnection.setDoOutput(true);
            httpsURLConnection.setRequestMethod("POST");
            httpsURLConnection.setRequestProperty("Charset", "utf-8");
            httpsURLConnection.setRequestProperty("Content-Length", Integer.toString(sb.length()));
            httpsURLConnection.setUseCaches(false);
            httpsURLConnection.connect();
            OutputStream outputStream = httpsURLConnection.getOutputStream();
            outputStream.write(bytes);
            outputStream.flush();
            outputStream.close();
            StringBuilder response = new StringBuilder();
            Reader reader = new BufferedReader(new InputStreamReader(httpsURLConnection.getInputStream()));
            char[] buff = new char[2048];
            while (true) {
                int read = reader.read(buff);
                if (read <= 0) {
                    break;
                }
                response.append(buff, 0, read);
            }
            Toast.makeText(this, response.toString(), Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, new StringBuffer().append("Exception: ").append(e).toString(), Toast.LENGTH_SHORT).show();
        }


    }


    public void editServer(final int position) {
        ServerDialog a = new ServerDialog(MainActivity.this);
        try {
            final JSONArray ja = new JSONArray(ServerData.getData());
            a.edit(ja.getJSONObject(position));
            a.onServerAdd(json -> {
                try {
                    String[] ob = {"Name", "serverType", "FLAG", "Category", "ServerIP", "ServerCloudFront", "ServerHTTP", "TcpPort", "SSLPort", "ProxyPort", "AutoLogIn", "Username", "Password", "MultiCert", "ovpnCertificate"};
                    for (int i = 0; i < ob.length; i++) {
                        ja.getJSONObject(position).remove(ob[i]);
                    }
                    for (int i = 0; i < json.length(); i++) {
                        ja.getJSONObject(position).put(ob[i], json.getString(ob[i]));
                    }
                    ServerData.updateData("1", ja.toString());
                    refreshALLAdapters();
                } catch (JSONException e) {
                    Toast.makeText(getBaseContext(), e.getMessage(), Toast.LENGTH_LONG).show();
                }
            });
            a.init();
        } catch (JSONException e) {
            Toast.makeText(getBaseContext(), e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    public void deleteServer(final int position) {
        try {
            JSONArray ja = new JSONArray(ServerData.getData());
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                ja.remove(position);
            }
            ServerData.updateData("1", ja.toString());
            refreshALLAdapters();
        } catch (JSONException e) {
            Toast.makeText(getBaseContext(), e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    public void add(View v) {
        ServerDialog a = new ServerDialog(this);
        a.add();
        a.onServerAdd(json -> {
            try {
                JSONArray ja = new JSONArray(ServerData.getData());
                ja.put(json);
                ServerData.updateData("1", ja.toString());
                refreshALLAdapters();
            } catch (JSONException e) {
                Toast.makeText(getBaseContext(), e.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
        a.init();
    }

    public void editPayload(final int position) {
        PayloadDialog a = new PayloadDialog(MainActivity.this);
        try {
            final JSONArray ja = new JSONArray(HTTPData.getData());
            a.edit(ja.getJSONObject(position));
            a.onPayloadAdd(json -> {
                try {
                    String[] ob = {"FLAG", "proto_spin", "server_type", "Name", "NetworkPayload", "Info", "UseDefProxy", "AutoReplace", "SquidProxy", "SquidPort", "NetworkFrontQuery", "NetworkBackQuery"};
                    for (int i = 0; i < ob.length; i++) {
                        ja.getJSONObject(position).remove(ob[i]);
                    }
                    for (int i = 0; i < json.length(); i++) {
                        ja.getJSONObject(position).put(ob[i], json.getString(ob[i]));
                    }
                    HTTPData.updateData("1", ja.toString());
                    refreshALLAdapters();
                } catch (JSONException e) {
                    Toast.makeText(getBaseContext(), e.getMessage(), Toast.LENGTH_LONG).show();
                }
            });
            a.init();
        } catch (JSONException e) {
            Toast.makeText(getBaseContext(), e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    public void deletePayload(int position) {
        try {
            JSONArray ja = new JSONArray(HTTPData.getData());
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                ja.remove(position);
            }
            HTTPData.updateData("1", ja.toString());
            refreshALLAdapters();
        } catch (JSONException e) {
            Toast.makeText(getBaseContext(), e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    public void addPayload(View v) {
        PayloadDialog a = new PayloadDialog(this);
        a.add();
        a.onPayloadAdd(json -> {
            try {
                JSONArray ja = new JSONArray(HTTPData.getData());
                ja.put(json);
                HTTPData.updateData("1", ja.toString());
                refreshALLAdapters();
            } catch (JSONException e) {
                Toast.makeText(getBaseContext(), e.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
        a.init();
    }

    public void edit(View v) {
        editServer(a.getSelectedItemPosition());
    }

    public void del(View v) {
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Delete Configuration")
                .setMessage("Are you sure you want to delete?")
                .setPositiveButton("YES", (dia, which) -> deleteServer(a.getSelectedItemPosition())).setNegativeButton("NO", null).create();
        dialog.show();

    }

    public void editPayload(View v) {
        editPayload(b.getSelectedItemPosition());
    }

    @Deprecated
    public void deletePayload(View v) {
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Delete Configuration")
                .setMessage("Are you sure you want to delete?")
                .setPositiveButton(android.R.string.yes, (dia, which) -> deletePayload(b.getSelectedItemPosition()))
                .setNegativeButton(android.R.string.no, null)
                .create();
        dialog.show();
    }

    public void addSSL(View v) {
        SSLDialog a = new SSLDialog(this);
        a.add();
        a.onPayloadAdd(json -> {
            try {
                JSONArray ja = new JSONArray(SSLData.getData());
                ja.put(json);
                SSLData.updateData("1", ja.toString());
                refreshALLAdapters();
            } catch (JSONException e) {
                Toast.makeText(getBaseContext(), e.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
        a.init();
    }

    public void editSSL(View v) {
        editSSL(c.getSelectedItemPosition());
    }

    public void editSSL(final int position) {
        SSLDialog a = new SSLDialog(MainActivity.this);
        try {
            final JSONArray ja = new JSONArray(SSLData.getData());
            a.edit(ja.getJSONObject(position));
            a.onPayloadAdd(json -> {
                try {
                    String[] ob = {"FLAG", "proto_spin", "server_type", "Name", "SSLSNI", "SSLPayload", "Info", "UseDefProxy", "SquidProxy", "SquidPort", "SSLPort"};
                    for (int i = 0; i < ob.length; i++) {
                        ja.getJSONObject(position).remove(ob[i]);
                    }
                    for (int i = 0; i < json.length(); i++) {
                        ja.getJSONObject(position).put(ob[i], json.getString(ob[i]));
                    }
                    SSLData.updateData("1", ja.toString());
                    refreshALLAdapters();
                } catch (JSONException e) {
                    Toast.makeText(getBaseContext(), e.getMessage(), Toast.LENGTH_LONG).show();
                }
            });
            a.init();
        } catch (JSONException e) {
            Toast.makeText(getBaseContext(), e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    public void delSSL(View v) {
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Delete Configuration")
                .setMessage("Are you sure you want to delete?")
                .setPositiveButton("YES", (dia, which) -> deleteSSL(c.getSelectedItemPosition())).setNegativeButton("NO", null).create();
        dialog.show();

    }

    public void deleteSSL(int position) {
        try {
            JSONArray ja = new JSONArray(SSLData.getData());
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                ja.remove(position);
            }
            SSLData.updateData("1", ja.toString());
            refreshALLAdapters();
        } catch (JSONException e) {
            Toast.makeText(getBaseContext(), e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }


    private JSONObject ja() {
        try {
            JSONArray ServerList = new JSONArray(ServerData.getData());
            JSONArray PayloadList = new JSONArray(HTTPData.getData());
            JSONArray SSLList = new JSONArray(SSLData.getData());
            return new JSONObject(sp.getString("Configuration", "{}"))
                    .put("FileName", sp.getString("_FileName", ""))
                    .put("Version", sp.getString("_Version", ""))
                    .put("ReleaseNotes", sp.getString("_ReleaseNotes", ""))
                    .put("contactSupport", sp.getString("_contactSupport", ""))
                    .put("Servers", ServerList)
                    .put("HTTPNetworks", PayloadList)
                    .put("SSLNetworks", SSLList)
                    .put("Ovpn_Cert", sp.getString("_SingleCert", ""));
        } catch (JSONException e) {
            return null;
        }
    }


    private ServerSpinnerAdapter adapter() {
        ArrayList<JSONObject> al = new ArrayList<>();
        ServerSpinnerAdapter ad = new ServerSpinnerAdapter(this, al);
        ad.setPath("servers");
        try {
            for (int i = 0; i < ja().getJSONArray("Servers").length(); i++) {
                JSONArray ja = ja().getJSONArray("Servers");
                al.add(ja.getJSONObject(i));
            }
            return ad;
        } catch (Exception e) {
            return null;
        }
    }

    private HTTPSpinnerAdapter adapterP() {
        ArrayList<JSONObject> al = new ArrayList<JSONObject>();
        HTTPSpinnerAdapter ad = new HTTPSpinnerAdapter(this, al);
        ad.setPath("HTTPNetworks");
        try {
            for (int i = 0; i < ja().getJSONArray("HTTPNetworks").length(); i++) {
                JSONArray ja = ja().getJSONArray("HTTPNetworks");
                al.add(ja.getJSONObject(i));
            }
            return ad;
        } catch (Exception e) {
            return null;
        }
    }

    private sslSpinnerAdapter adapterSSL() {
        ArrayList<JSONObject> al = new ArrayList<JSONObject>();
        sslSpinnerAdapter ad = new sslSpinnerAdapter(this, al);
        ad.setPath("SSLNetworks");
        try {
            for (int i = 0; i < ja().getJSONArray("SSLNetworks").length(); i++) {
                JSONArray ja = ja().getJSONArray("SSLNetworks");
                al.add(ja.getJSONObject(i));
            }
            return ad;
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add(1, 1, 1, "Clear Data").setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
        menu.add(2, 2, 2, "Exit").setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
        return super.onCreateOptionsMenu(menu);
    }

    @Deprecated
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case 1:
                AlertDialog dialog = new AlertDialog.Builder(this)
                        .setTitle("Reset Configuration")
                        .setMessage("Are you sure you want to reset?")
                        .setPositiveButton(android.R.string.yes, (dia, which) -> {
                            setDefaultJson();
                            refreshALLAdapters();
                        })
                        .setNegativeButton(android.R.string.no, null)
                        .create();
                dialog.show();
                break;
            case 2:
                FileUtil.exitAll(MainActivity.this);
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    private void ExportOnline() {
        final AlertDialog.Builder a = new AlertDialog.Builder(this);
        View v = LayoutInflater.from(this).inflate(R.layout.password, null);
        a.setIcon(R.drawable.icon2);
        a.setTitle("Online Json");
        a.setView(v);
        final SharedPreferences mPref = getSharedPreferences("mKEYGEN", MODE_PRIVATE);
        final EditText configUrl = v.findViewById(R.id.configUrl);
        configUrl.setText(mPref.getString("_configUrl", ""));
        a.setNegativeButton("Cancel", null);
        a.setPositiveButton("Import Json", (p1, p2) -> {
            mPref.edit().putString("_configUrl", configUrl.getText().toString()).apply();
            String mURL = (configUrl.getText().toString().startsWith("http")) ? configUrl.getText().toString() : "https://" + configUrl.getText().toString();
            new checkUpdate(MainActivity.this, mURL, new checkUpdate.Listener() {
                @Override
                public void onError(String config) {
                    Toast.makeText(MainActivity.this, config, Toast.LENGTH_LONG).show();
                }

                @Override
                public void onCompleted(final String config) {
                    if (config.isEmpty()) {
                        Toast.makeText(MainActivity.this, "Something went wrong...", Toast.LENGTH_LONG).show();
                        return;
                    }
                    setDefaultJson();
                    importFile(config);
                }
            }).start();
        });
        a.create().show();
    }

    private void importFile(String data) {

        String mData = FileUtil.showJs(this, data);
        if (TextUtils.isEmpty(data)) {
            sp.edit().clear().apply();
            Toast.makeText(getApplicationContext(), "Something went wrong...", Toast.LENGTH_LONG).show();
            startActivity(new Intent(MainActivity.this, LauncherActivity.class));
            MainActivity.this.finish();
        } else {
            try {
                JSONObject obj = new JSONObject(mData.trim());
                sp.edit().putString("_FileName", obj.getString("FileName")).apply();
                sp.edit().putString("_Version", obj.getString("Version")).apply();
                sp.edit().putString("_ReleaseNotes", obj.getString("ReleaseNotes")).apply();
                sp.edit().putString("_contactSupport", obj.getString("contactSupport")).apply();
                sp.edit().putString("_SingleCert", obj.getString("Ovpn_Cert")).apply();
                ServerData.updateData("1", obj.getJSONArray("Servers").toString());
                HTTPData.updateData("1", obj.getJSONArray("HTTPNetworks").toString());
                SSLData.updateData("1", obj.getJSONArray("SSLNetworks").toString());
                refreshALLAdapters();
                Toast.makeText(getApplicationContext(), "ImportedJs Successfully", Toast.LENGTH_LONG).show();
            } catch (Exception e) {
                Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG).show();
            }
        }
    }

    private void clear_warning(final int activity) {
        if (ServerData.getData().equals("[]") || HTTPData.getData().equals("[]") || SSLData.getData().equals("[]")) {
            if (activity == 1) {
                startActivity(new Intent(MainActivity.this, ConfigImportFileActivity.class));
            }
            return;
        }
        AlertDialog.Builder dialog = new AlertDialog.Builder(this)
                .setTitle("Clear Configuration")
                .setIcon(R.drawable.icon1)
                .setMessage("Clear first to continue activity!")
                .setPositiveButton("Continue", (p1, p2) -> {
                    setDefaultJson();
                    refreshALLAdapters();
                    if (activity == 1) {
                        startActivity(new Intent(MainActivity.this, ConfigImportFileActivity.class));
                    }
                    p1.dismiss();
                })
                .setNegativeButton("Cancel", null);
        AlertDialog alertDialog = dialog.create();
        alertDialog.show();
    }

    private void setDefaultJson() {
        sp.edit().clear().apply();
        ServerData.updateData("1", "[]");
        HTTPData.updateData("1", "[]");
        SSLData.updateData("1", "[]");
    }

    private void refreshALLAdapters() {
        fn_lay.setVisibility(sp.getString("fileFolder", "").isEmpty() ? View.GONE : View.VISIBLE);
        rn_lay.setVisibility(sp.getString("_ReleaseNotes", "").isEmpty() ? View.GONE : View.VISIBLE);
        vs_lay.setVisibility(sp.getString("_Version", "").isEmpty() ? View.GONE : View.VISIBLE);
        mFileName.setText(sp.getString("fileFolder", ""));
        mLogs.setText(sp.getString("_ReleaseNotes", ""));
        mVersion.setText(sp.getString("_Version", ""));
        if (adapter() != null) {
            a.setAdapter(adapter());
        }
        if (adapterP() != null) {
            b.setAdapter(adapterP());
        }
        if (adapterSSL() != null) {
            c.setAdapter(adapterSSL());
        }
    }

    private void en_de_text(String m, String r) {
        LayoutInflater inflater = LayoutInflater.from(MainActivity.this);
        final View view = inflater.inflate(R.layout.en_de, null);
        AlertDialog.Builder certDialog = new AlertDialog.Builder(this);
        certDialog.setView(view);
        certDialog.setTitle("Encrypt/Decrypt");
        certDialog.setIcon(R.drawable.icon7);
        certDialog.setCancelable(false);
        final EditText msg = view.findViewById(R.id.text_message);
        final TextView result = view.findViewById(R.id.result_message);
        msg.setText(m);
        result.setText(r);
        certDialog.setNeutralButton("Close", (p1, p2) -> p1.dismiss());
        certDialog.setNegativeButton("Encrypt", (p1, p2) -> {
            String ms = msg.getText().toString().trim();
            String en = FileUtil.hideJs(MainActivity.this, ms);
            en_de_text(ms, en);
        });
        certDialog.setPositiveButton("Decrypt", (p1, p2) -> {
            String ms = msg.getText().toString().trim();
            String de = FileUtil.showJs(MainActivity.this, ms);
            en_de_text(ms, de);
        });
        AlertDialog cDialog = certDialog.create();
        cDialog.show();
    }

    private void setCERTIFICATE() {
        LayoutInflater inflater = LayoutInflater.from(MainActivity.this);
        final View view = inflater.inflate(R.layout.openvpn_cert, null);
        AlertDialog.Builder certDialog = new AlertDialog.Builder(this);
        certDialog.setView(view);
        certDialog.setTitle("OVPN CERTIFICATE");
        certDialog.setIcon(R.drawable.icon6);
        certDialog.setCancelable(false);
        final EditText mCertificate = view.findViewById(R.id.BEGIN_CERTIFICATE);

        if (!sp.getString("_SingleCert", "").isEmpty()) {
            mCertificate.setText(FileUtil.showJs(this, sp.getString("_SingleCert", "")));
        } else mCertificate.setText("client\n" +
                "dev tun\n" +
                "proto tcp\n" +
                "remote SERVERIPADDRESSHERE 1194\n" +
                "cipher AES-256-GCM\n" +
                "auth none\n" +
                "auth-user-pass\n" +
                "resolv-retry infinite\n" +
                "connect-retry 0 1\n" +
                "remote-cert-tls server\n" +
                "redirect-gateway def1\n" +
                "setenv CLIENT_CERT 0\n" +
                "verb 3\n" +
                "<ca>\n" +
                "-----BEGIN CERTIFICATE-----\n" +
                "MIIFBDCCA+ygAwIBAgIUUmdgPaIpFzVfyrlKjuKAdPPOZOswDQYJKoZIhvcNAQEL\n" +
                "BQAwgaoxCzAJBgNVBAYTAlBIMQswCQYDVQQIEwJNQTEWMBQGA1UEBxMNQW50aXBv\n" +
                "bG8gQ2l0eTESMBAGA1UEChMJVEtOZXR3b3JrMRIwEAYDVQQLEwlUS05lcndvcmsx\n" +
                "FTATBgNVBAMTDFRLTmV0d29yayBDQTESMBAGA1UEKRMJVEtOZXR3b3JrMSMwIQYJ\n" +
                "KoZIhvcNAQkBFhRlcmljbGF5bGF5QGdtYWlsLmNvbTAeFw0yMjA5MjAwMzUzMDda\n" +
                "Fw0zMjA5MTcwMzUzMDdaMIGqMQswCQYDVQQGEwJQSDELMAkGA1UECBMCTUExFjAU\n" +
                "BgNVBAcTDUFudGlwb2xvIENpdHkxEjAQBgNVBAoTCVRLTmV0d29yazESMBAGA1UE\n" +
                "CxMJVEtOZXJ3b3JrMRUwEwYDVQQDEwxUS05ldHdvcmsgQ0ExEjAQBgNVBCkTCVRL\n" +
                "TmV0d29yazEjMCEGCSqGSIb3DQEJARYUZXJpY2xheWxheUBnbWFpbC5jb20wggEi\n" +
                "MA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCdQ4Q5U25/QyOPi9s7X9GrzKYh\n" +
                "huF5twr7rneZrJPWKy7rDDvhpUOqTyv/FI3PX3BbZKbXOnFGxFyNpkqnL/5nyoxa\n" +
                "ma5WeYgcCN4PHmUd46bOX7HFl7ydHo+OutDM9xP8g8VOfFDjiNjlcpI0qTkBOm2k\n" +
                "um5Bx7Z6CxDblT+iXAQ1Pv0F7EYclKcAxSlEwG/phdXTkshx7wsqzilorouLoZ4N\n" +
                "iB+Sv7vWQY1i0HS3IOv9xG0xTW5LKt3ub5ZrkIs+JBXlyR3L953i3OzP3uQ9gQcL\n" +
                "/w/6XSN1opR3NYfFpL4QsSVJDRiASU9oWyuyZ2K/hiFdMG9vpwjMomEINDRxAgMB\n" +
                "AAGjggEeMIIBGjAdBgNVHQ4EFgQU22vZfsw2ER5n6EWwByaIF/aL86swgeoGA1Ud\n" +
                "IwSB4jCB34AU22vZfsw2ER5n6EWwByaIF/aL86uhgbCkga0wgaoxCzAJBgNVBAYT\n" +
                "AlBIMQswCQYDVQQIEwJNQTEWMBQGA1UEBxMNQW50aXBvbG8gQ2l0eTESMBAGA1UE\n" +
                "ChMJVEtOZXR3b3JrMRIwEAYDVQQLEwlUS05lcndvcmsxFTATBgNVBAMTDFRLTmV0\n" +
                "d29yayBDQTESMBAGA1UEKRMJVEtOZXR3b3JrMSMwIQYJKoZIhvcNAQkBFhRlcmlj\n" +
                "bGF5bGF5QGdtYWlsLmNvbYIUUmdgPaIpFzVfyrlKjuKAdPPOZOswDAYDVR0TBAUw\n" +
                "AwEB/zANBgkqhkiG9w0BAQsFAAOCAQEAFxk8YMHYAjggbj6T8HliynV/fMEbhZxx\n" +
                "HIpQyUmOhUOf1LidztC6w/cpO7Cx+esobwfgxGFnx854cnDHZ77/MmZHiGV3Rn91\n" +
                "rmv3xPc0FFiH+Cb4IVXtaPr1hUE45Eey+Odpy3Tj9wOC29lS4P5q9GgcnuNXj4Db\n" +
                "W/jcb2uW3xcdHPj1slhy4Wl/h6Qe5vHqp2jOfMZISKiF3keTAiYnXJWTsSPeOkOD\n" +
                "NvgKUnh6Z3K8NaUlw0SyhzMVwKDKExmMQUcHXAtF2JDrQwerB29jQBd+iFNVV3in\n" +
                "Pz2wHWMTqDV4pSJL4APX/Y9TC7jsi7d0rq9+gmOOFp1OAe11PSTamg==\n" +
                "-----END CERTIFICATE-----\n" +
                "</ca>");
        certDialog.setNeutralButton("Close", (p1, p2) -> p1.dismiss());
        certDialog.setNegativeButton("Clear", (p1, p2) -> {
            mCertificate.setText("");
            sp.edit().putString("_SingleCert", "").apply();
        });
        certDialog.setPositiveButton("Save", (p1, p2) -> {
            sp.edit().putString("_SingleCert", FileUtil.hideJs(MainActivity.this, mCertificate.getText().toString())).apply();
            p1.dismiss();
        });
        AlertDialog cDialog = certDialog.create();
        if (!cDialog.isShowing()) cDialog.show();
    }

}

