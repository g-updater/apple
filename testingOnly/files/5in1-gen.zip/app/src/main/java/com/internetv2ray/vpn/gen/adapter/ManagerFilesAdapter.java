package com.internetv2ray.vpn.gen.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.io.File;
import java.util.List;
import androidx.recyclerview.widget.RecyclerView;

import com.internetv2ray.vpn.gen.R;

public class ManagerFilesAdapter
        extends RecyclerView.Adapter<ManagerFilesAdapter.ItemHolder>
{
        
        private List<ManagerItem> items;
        private LayoutInflater layoutInflater;
        private OnItemClickListener clickListener;

        
        public interface OnItemClickListener {
                void onItemClick(View view, int position);
                void onItemLongClick(View view, int position);
        }
        
        public static class ManagerItem implements Comparable<ManagerItem> {
                private String dirName;
                private String dirPath;
                private String dirNameSecond;

                public ManagerItem(String dirName, String dirPath, String dirNameSecond) {
                        this.dirName = dirName;
                        this.dirPath = dirPath;
                        this.dirNameSecond = dirNameSecond;
                }

                public void setDirName(String dirName) {
                        this.dirName = dirName;
                }

                public String getDirName() {
                        return dirName;
                }

                public void setDirPath(String dirPath) {
                        this.dirPath = dirPath;
                }

                public String getDirPath() {
                        return dirPath;
                }
                
                public void setNameSecond(String str) {
                        this.dirNameSecond = str;
                }
                
                public String getNameSecond() {
                        return dirNameSecond;
                }

                @Override
                public int compareTo(ManagerItem managerDir) {
                        return dirName.compareToIgnoreCase(managerDir.getDirName());
                }
        }
        
        public class ItemHolder extends RecyclerView.ViewHolder {
                TextView tvItemName;
                ImageView ivImage;
                LinearLayout tvItemLayout;
                TextView tvItemNameSecond;

                public ItemHolder(View view) {
                        super(view);
                        tvItemLayout = (LinearLayout) view.findViewById(R.id.ivManagerAdapter_ItemLayout);
                        tvItemName = (TextView) view.findViewById(R.id.tvManagerAdapter_FolderName);
                        ivImage = (ImageView) view.findViewById(R.id.ivManagerAdapter_ImageIcon);
                        tvItemNameSecond = (TextView) view.findViewById(R.id.tvManagerAdapter_FolderNameDate);
                }
        }
        
        
        public ManagerFilesAdapter(Context context, List<ManagerItem> items) {
                this.layoutInflater = LayoutInflater.from(context);
                this.items = items;
        }

        @Override
        public ManagerFilesAdapter.ItemHolder onCreateViewHolder(ViewGroup parent, int position) {
                View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item_manager, parent, false);
                ItemHolder item = new ItemHolder(view);
                return item;
        }

        @Override
        @SuppressLint("RecyclerView")
        public void onBindViewHolder(final ManagerFilesAdapter.ItemHolder item, final int position) {
                ManagerItem manager = items.get(position);
                String dirName = manager.getDirName();
                item.tvItemName.setText(dirName);
                item.tvItemNameSecond.setText(manager.getNameSecond());
                
                if (new File(manager.getDirPath()).isFile()) {
                        item.ivImage.setImageResource(R.drawable.mtk_logo);
                } else if (dirName.endsWith("...")) {
                        item.ivImage.setImageResource(R.drawable.ic_back);
                } else {
                        item.ivImage.setImageResource(R.drawable.ic_folder_icon);
                }
                
                item.tvItemLayout.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                                if (clickListener != null) {
                                        clickListener.onItemClick(view, position);
                                }
                        }
                });

                item.tvItemLayout.setOnLongClickListener(new View.OnLongClickListener() {
                        @Override
                        public boolean onLongClick(View v) {
                                if (clickListener != null) {
                                        clickListener.onItemLongClick(v, position);
                                }
                                return true;
                        }
                });
        }

        @Override
        public int getItemCount() {
                return items.size();
        }

        public void setOnItemClickListener(OnItemClickListener itemClickListener) {
                this.clickListener = itemClickListener;
        }
        
}

