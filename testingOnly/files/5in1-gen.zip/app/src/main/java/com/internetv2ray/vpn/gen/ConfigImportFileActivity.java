package com.internetv2ray.vpn.gen;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Reader;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONObject;
import android.content.SharedPreferences;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.internetv2ray.vpn.gen.adapter.ManagerFilesAdapter;
import com.internetv2ray.vpn.gen.util.DataBaseHelper;
import com.internetv2ray.vpn.gen.util.FileUtil;

import javax.net.ssl.HttpsURLConnection;

public class ConfigImportFileActivity extends AppCompatActivity implements ManagerFilesAdapter.OnItemClickListener {
    private static final String TAG = ConfigImportFileActivity.class.getSimpleName();

    private static final String RESTORE_CURRENT_PATH = "restoreCurrentPath";
    private static final String HOME_PATH = Environment.getExternalStorageDirectory().toString();
    private static final int PERMISSION_REQUEST_CODE = 1;
    private static final String BACK_DIR = "../";
    private RecyclerView rvManagerList;
    private ManagerFilesAdapter adapter;
    private List<ManagerFilesAdapter.ManagerItem> folderList;
    private List<ManagerFilesAdapter.ManagerItem> fileList;
    private String currentPath;
    private File backDir;
    private String pathAbertoPeloInicio;
    private SharedPreferences sp;
    private DataBaseHelper ServerData,HTTPData,SSLData;








    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent intent = getIntent();
        String scheme = intent.getScheme();
        ServerData = new DataBaseHelper(this,"ServerData");
        HTTPData = new DataBaseHelper(this,"HTTPData");
        SSLData = new DataBaseHelper(this,"SSLData");
        sp = getSharedPreferences("TKApplication", MODE_PRIVATE);
        if (scheme != null && (scheme.equals("file") || scheme.equals("content"))) {
            setContentView(R.layout.launchvpn);
            Uri data = intent.getData();
            File file = new File(data.getPath());
            String file_extensao = getExtension(file);
            if (file_extensao != null /*&& file_extensao.equals(".hs")*/) {
                String fileContent = FileUtil.readTextUri(this,data);
                try {
                    importFile(fileContent);
                }catch (Exception ex){
                    Toast.makeText(ConfigImportFileActivity.this, ex.getMessage(), Toast.LENGTH_LONG).show();
                    sp.edit().clear().apply();
                    startActivity(new Intent(ConfigImportFileActivity.this, LauncherActivity.class));
                    ConfigImportFileActivity.this.finish();
                }
            }
            else {
                Toast.makeText(this, "Unsupported file",Toast.LENGTH_SHORT).show();
            }
            ConfigImportFileActivity.this.finish();
            return;
        }

        // set Views
        setContentView(R.layout.activity_config_import);
        this.setFinishOnTouchOutside(false);
        rvManagerList = (RecyclerView) findViewById(R.id.rvMain_ManagerList);
        setToolbar();
        if (!FileUtil.isStorageReadable(this)) {
            requestPermissionInfo();
            return;
        }
        if (savedInstanceState != null) {
            currentPath = savedInstanceState.getString(RESTORE_CURRENT_PATH);
            fileManager(currentPath);
        } else {
            startMainListManager();
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        outState.putString(RESTORE_CURRENT_PATH, currentPath);
        super.onSaveInstanceState(outState);
    }
    @Override
    public void onItemClick(View view, int position) {
        File file = new File(folderList.get(position).getDirPath());
        if (file.isDirectory()) {
            fileManager(folderList.get(position).getDirPath());
        } else {
            String file_extensao = getExtension(file);
            if (file_extensao != null/* && file_extensao.equals(".hs")*/) {
                String fileContent = FileUtil.readTextFile(file);
                try {
                    importFile(fileContent);
                }catch (Exception ex){
                    Toast.makeText(ConfigImportFileActivity.this, ex.getMessage(), Toast.LENGTH_LONG).show();
                    sp.edit().clear().apply();
                    startActivity(new Intent(ConfigImportFileActivity.this, LauncherActivity.class));
                    ConfigImportFileActivity.this.finish();
                }
            }
        }
    }

    @Override
    public void onItemLongClick(View view, int position)
    {
        File file = new File(folderList.get(position).getDirPath());
        if (!file.isDirectory()) {
            showApagarPrompt(file);
        }
    }

    private void startMainListManager() {
        folderList = new ArrayList<>();
        fileList = new ArrayList<>();
        currentPath = null;
        pathAbertoPeloInicio = null;
        if (mToolbar != null) {
            mToolbar.setSubtitle("Select file");
        }
        backDir = null;
        String[] listDirs = {
            HOME_PATH,
            HOME_PATH + "/Download",
            HOME_PATH + "/Syopaw"
        };
        for (String dir : listDirs) {
            File file = new File(dir);
            if (file.exists() && !file.isHidden() && file.canRead()) {
                if (file.isDirectory()) {
                    String dir_name = file.getName();

                    if (dir.equals(HOME_PATH))
                        dir_name = "Internal memory";

                    folderList.add(new ManagerFilesAdapter.ManagerItem(dir_name, file.getPath(), "Folder"));
                }
            }

        }
        folderList.addAll(fileList);
        adapter = new ManagerFilesAdapter(this, folderList);
        rvManagerList.setLayoutManager(new LinearLayoutManager(this));
        adapter.setOnItemClickListener(this);
        rvManagerList.setAdapter(adapter);
    }

    private void fileManager(String folderPath) {
        if (folderPath == null || folderPath.equals(BACK_DIR)) {
            if (backDir != null && canGoBackFolder())
                folderPath = backDir.getPath();
            else {
                startMainListManager();
                return;
            }
        }
        folderList = new ArrayList<>();
        fileList = new ArrayList<>();
        if (currentPath == null) {
            pathAbertoPeloInicio = folderPath;
        }
        currentPath = folderPath;
        if (mToolbar != null) {
            mToolbar.setSubtitle(folderPath);
        }
        File path = new File(folderPath);
        if (path.getParentFile() != null && !currentPath.equals(pathAbertoPeloInicio)) {
            backDir = path.getParentFile();
        }
        for (File file : path.listFiles()) {
            if (!file.isHidden() && file.canRead()) {
                if (file.isDirectory()) {
                    folderList.add(new ManagerFilesAdapter.ManagerItem(file.getName(), file.getPath(), "Folder"));
                } else {
                    String file_extensao = getExtension(file);
                    if (file_extensao != null && file_extensao.equals(".hs")) {
                        String dateLastModified = String.format("%s %s",
                                                                android.text.format.DateFormat.getDateFormat(this).format(file.lastModified()),
                                                                android.text.format.DateFormat.getTimeFormat(this).format(file.lastModified()));
                        fileList.add(new ManagerFilesAdapter.ManagerItem(file.getName(), file.getPath(), dateLastModified));
                    }
                }
            }
        }
        Collections.sort(folderList);
        Collections.sort(fileList);
        folderList.addAll(fileList);
        if (canGoBackFolder() || currentPath.equals(pathAbertoPeloInicio)) {
            folderList.add(0, new ManagerFilesAdapter.ManagerItem("...", BACK_DIR, "Folder"));
        }
        adapter = new ManagerFilesAdapter(this, folderList);
        rvManagerList.setLayoutManager(new LinearLayoutManager(this));
        adapter.setOnItemClickListener(this);
        rvManagerList.setAdapter(adapter);
    }

    @Override
    public void onBackPressed() {
        if (canGoBackFolder() || currentPath != null && currentPath.equals(pathAbertoPeloInicio)) {
            fileManager(BACK_DIR);
        }
        else {
            ConfigImportFileActivity.this.finish();
        }
    }

    private boolean canGoBackFolder() {
        if (backDir != null) {
            return backDir.canRead() && !backDir.getPath().equals(currentPath);
        }
        return false;
    }

    private void requestPermissionInfo() {
        if (ActivityCompat.shouldShowRequestPermissionRationale(ConfigImportFileActivity.this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
            AlertDialog.Builder dialog = new AlertDialog.Builder(this);
            dialog.setTitle("Grant Permissions");
            dialog.setMessage("Please, it is necessary to grant necessary permissions for the application to work properly.");
            dialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
                    @Override
                    public void onCancel(DialogInterface dialog) {
                        ConfigImportFileActivity.this.finish();
                    }
                });
            dialog.setPositiveButton("ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int position) {
                        ActivityCompat.requestPermissions(ConfigImportFileActivity.this, new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, PERMISSION_REQUEST_CODE);
                        dialogInterface.dismiss();
                    }
                });
            dialog.setNegativeButton("cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int position) {
                        dialogInterface.dismiss();
                        ConfigImportFileActivity.this.finish();
                    }
                });
            dialog.show();
        } else {
            ActivityCompat.requestPermissions(ConfigImportFileActivity.this, new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, PERMISSION_REQUEST_CODE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case PERMISSION_REQUEST_CODE:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    startMainListManager();
                } else {
                    requestPermissionInfo();
                }
                break;
        }
    }

    public String getExtension(File file) {
        String filename = file.getAbsolutePath();
        if (filename.contains(".")) {
            return filename.substring(filename.lastIndexOf(".") + 1);
        }
        return "";
    }
    
    private void importFile(String data){
        boolean isImported = false;
        String mData = FileUtil.showJs(ConfigImportFileActivity.this, data);
        if(mData==null|mData.isEmpty()|mData.equals("")){
            isImported = false;
            sp.edit().clear().apply();
            Toast.makeText(getApplicationContext(), "Something went wrong...", Toast.LENGTH_LONG).show();
            startActivity(new Intent(ConfigImportFileActivity.this, LauncherActivity.class));
            ConfigImportFileActivity.this.finish();
        } else {
            try {
                JSONObject obj = new JSONObject(mData.trim());
                sp.edit().putString("_FileName" , obj.getString("FileName")).apply();
                sp.edit().putString("_Version" ,obj.getString("Version")).apply();
                sp.edit().putString("_ReleaseNotes", obj.getString("ReleaseNotes")).apply();
                sp.edit().putString("_contactSupport",obj.getString("contactSupport")).apply();
                sp.edit().putString("_SingleCert",obj.getString("Ovpn_Cert")).apply();
                ServerData.updateData("1",obj.getJSONArray("Servers").toString());
                HTTPData.updateData("1",obj.getJSONArray("HTTPNetworks").toString());
                SSLData.updateData("1",obj.getJSONArray("SSLNetworks").toString());
                isImported = true;
            } catch (Exception e) {
                isImported = false;
                Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG).show();
            }
            if(isImported){
                MainActivity.updateMainViews(ConfigImportFileActivity.this);
                Intent intent = new Intent(ConfigImportFileActivity.this, MainActivity.class);
                ConfigImportFileActivity.this.startActivity(intent);
                ConfigImportFileActivity.this.finish();
            }
        }
    }

    private Toolbar mToolbar;
    private void setToolbar() {
        mToolbar = (Toolbar) findViewById(R.id.toolbar_main);
        mToolbar.setLogo(R.drawable.icon5);
        setSupportActionBar(mToolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        mToolbar.setNavigationOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ConfigImportFileActivity.this.finish();
                }
            });
    }

    private void showApagarPrompt(final File file) {
        AlertDialog dialog = new AlertDialog.Builder(this).create();
        dialog.setTitle("Exclude File");
        dialog.setMessage("Do you want to exclude that file?");
        dialog.setButton(dialog.BUTTON_POSITIVE, "yes", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface p1, int p2)
                {
                    if (file.delete())
                        fileManager(currentPath);
                    else
                        Toast.makeText(getApplicationContext(), "Failed to delete file",Toast.LENGTH_SHORT).show();
                }
            });
        dialog.setButton(dialog.BUTTON_NEGATIVE, "no", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface p1, int p2) {}
            });
        dialog.show();
    }

}

