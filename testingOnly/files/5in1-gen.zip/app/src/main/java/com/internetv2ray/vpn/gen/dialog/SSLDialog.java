package com.internetv2ray.vpn.gen.dialog;

import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import com.google.android.material.textfield.TextInputLayout;
import com.internetv2ray.vpn.gen.R;
import com.internetv2ray.vpn.gen.adapter.pAdapter;
import com.internetv2ray.vpn.gen.listener.SpinnerListener;
import com.internetv2ray.vpn.gen.util.FileUtil;
import org.json.JSONObject;
import java.util.ArrayList;
import com.internetv2ray.vpn.gen.util.gen;

public class SSLDialog {

    private AlertDialog a;
    private Context c;
    private RadioGroup server_type;
    private Spinner pLogo,sslmethod;
    private CheckBox ckUseDefProxy;
    private View v;
    private EditText etSSLName,etSSLSNI,etSSLPayload,etSSLInfo,etSquidProxy,etSquidPort,etSSLPort;
    private boolean isAdd = true;
    public SSLDialog(Context c) {
        a = new AlertDialog.Builder(c).create();
        a.setTitle("Add SSL Network");
        a.setCancelable(false);
        this.c = c;
    }

    private String mServerType(){
        if(server_type.getCheckedRadioButtonId()==R.id.cf_radio){
            return "cf";
        }
        if(server_type.getCheckedRadioButtonId()==R.id.ws_radio){
            return "ws";
        }
        return "http";
    }
    
    public void add() {
        isAdd = true;
        v = LayoutInflater.from(c).inflate(R.layout.dialog_add_ssl, null);
        pLogo = v.findViewById(R.id.pLogo);
        sslmethod = v.findViewById(R.id.sslmethod);
        server_type = v.findViewById(R.id.server_type);
        etSSLName = v.findViewById(R.id.etSSLName);
        etSSLSNI = v.findViewById(R.id.etSSLSNI);
        etSSLPayload = v.findViewById(R.id.etSSLPayload);
        etSSLInfo = v.findViewById(R.id.etSSLInfo);
        ckUseDefProxy = v.findViewById(R.id.ckUseDefProxy);
        etSquidProxy = v.findViewById(R.id.etSquidProxy);
        etSquidPort = v.findViewById(R.id.etSquidPort);
        etSSLPort = v.findViewById(R.id.etSSLPort);
        ckUseDefProxy.setChecked(true);
        etSquidProxy.setEnabled(false);
        etSquidPort.setEnabled(false);
        server_type.check(R.id.cf_radio);
        sslmethod.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position==0){
                    v.findViewById(R.id.etSSLPayload_ly).setVisibility(View.GONE);
                    v.findViewById(R.id.sslproxylay).setVisibility(View.GONE);
                }else if (position==1){
                    v.findViewById(R.id.etSSLPayload_ly).setVisibility(View.VISIBLE);
                    v.findViewById(R.id.sslproxylay).setVisibility(View.GONE);
                }
                else if (position==2){
                    v.findViewById(R.id.etSSLPayload_ly).setVisibility(View.VISIBLE);
                    v.findViewById(R.id.sslproxylay).setVisibility(View.VISIBLE);
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
        ckUseDefProxy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View p1) {
                if (ckUseDefProxy.isChecked()){
                    etSquidProxy.setText("[Default]");
                    etSquidProxy.setEnabled(false);
                    etSquidPort.setEnabled(false);
                }else {
                    etSquidProxy.setText("");
                    etSquidProxy.setEnabled(true);
                    etSquidPort.setEnabled(true);
                }
            }
        });
        v.findViewById(R.id.btnPayloadGen).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View p1) {
                    gen pg = new gen(c);
                    pg.setGenerateListener("Generate", new gen.OnGenerateListener() {
                            @Override
                            public void onGenerate(String payloadGenerated) {
                                etSSLPayload.setText(payloadGenerated);
                            }
                        });
                    pg.show();
                }
            });
        try {
            String[] list = c.getAssets().list("networks");
            ArrayList<String> plg = new ArrayList();
            for (int i = 0; i < list.length; i++) {
                plg.add(list[i].replace("icon_","").replace(".png",""));
            }
            pLogo.setAdapter(new pAdapter(c,plg));
        } catch (Exception e) {
            Toast.makeText(c,e.getMessage(), Toast.LENGTH_LONG).show();
        }
        a.setView(v);
    }

    public void edit(JSONObject json) {
        isAdd = false;
        v=LayoutInflater.from(c).inflate(R.layout.dialog_add_ssl, null);
        pLogo = v.findViewById(R.id.pLogo);
        sslmethod = v.findViewById(R.id.sslmethod);
        server_type = v.findViewById(R.id.server_type);
        etSSLName = v.findViewById(R.id.etSSLName);
        etSSLSNI = v.findViewById(R.id.etSSLSNI);
        etSSLPayload = v.findViewById(R.id.etSSLPayload);
        etSSLInfo = v.findViewById(R.id.etSSLInfo);
        ckUseDefProxy = v.findViewById(R.id.ckUseDefProxy);
        etSquidProxy = v.findViewById(R.id.etSquidProxy);
        etSquidPort = v.findViewById(R.id.etSquidPort);
        etSSLPort = v.findViewById(R.id.etSSLPort);
        sslmethod.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position==0){
                    v.findViewById(R.id.etSSLPayload_ly).setVisibility(View.GONE);
                    v.findViewById(R.id.sslproxylay).setVisibility(View.GONE);
                }else if (position==1){
                    v.findViewById(R.id.etSSLPayload_ly).setVisibility(View.VISIBLE);
                    v.findViewById(R.id.sslproxylay).setVisibility(View.GONE);
                }
                else if (position==2){
                    v.findViewById(R.id.etSSLPayload_ly).setVisibility(View.VISIBLE);
                    v.findViewById(R.id.sslproxylay).setVisibility(View.VISIBLE);
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
        ckUseDefProxy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View p1) {
                if (ckUseDefProxy.isChecked()){
                    etSquidProxy.setText("[Default]");
                    etSquidProxy.setEnabled(false);
                    etSquidPort.setEnabled(false);
                }else {
                    etSquidProxy.setText("");
                    etSquidProxy.setEnabled(true);
                    etSquidPort.setEnabled(true);
                }
            }
        });
        v.findViewById(R.id.btnPayloadGen).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View p1) {
                    gen pg = new gen(c);
                    pg.setGenerateListener("Generate", new gen.OnGenerateListener() {
                            @Override
                            public void onGenerate(String payloadGenerated) {
                                etSSLPayload.setText(payloadGenerated);
                            }
                        });
                    pg.show();
                }
            });
        try {
            String[] list = c.getAssets().list("networks");
            ArrayList<String> plg = new ArrayList();
            for (int i = 0; i < list.length; i++) {
                plg.add(list[i].replace("icon_","").replace(".png",""));
            }
            pLogo.setAdapter(new pAdapter(c,plg));
        } catch (Exception e) {
            Toast.makeText(c,e.getMessage(), Toast.LENGTH_LONG).show();
        }
        try {
            String[] list = c.getAssets().list("networks");
            for (int i = 0; i < list.length; i++) {
                if (list[i].replace("icon_","").replace(".png", "").equals(json.getString("FLAG"))) {
                    pLogo.setSelection(i);
                }
            }
            sslmethod.setSelection(json.getInt("proto_spin")-3);
            etSSLName.setText(json.getString("Name"));
            etSSLSNI.setText(FileUtil.showJs(c,json.getString("SSLSNI")));
            etSSLPayload.setText(FileUtil.showJs(c,json.getString("SSLPayload")));
            etSSLInfo.setText(json.getString("Info"));
            ckUseDefProxy.setChecked(json.getBoolean("UseDefProxy"));
            etSquidPort.setText(json.getString("SquidPort"));
            etSSLPort.setText(json.getString("SSLPort"));
            if(json.getString("server_type").equals("cf")){
                server_type.check(R.id.cf_radio);
            }
            if(json.getString("server_type").equals("ws")){
                server_type.check(R.id.ws_radio);
            }
            if(json.getString("server_type").equals("http")){
                server_type.check(R.id.http_radio);
            }
            if (json.getBoolean("UseDefProxy")){
                etSquidProxy.setText("[Default]");
                etSquidProxy.setEnabled(false);
                etSquidPort.setEnabled(false);
            }else {
                etSquidProxy.setText(FileUtil.showJs(c,json.getString("SquidProxy")));
                etSquidProxy.setEnabled(true);
                etSquidPort.setEnabled(true);
            }
        } catch (Exception e) {
            Toast.makeText(c, e.getMessage(), Toast.LENGTH_LONG).show();
        }
        a.setView(v);
    }

    public void onPayloadAdd(final SpinnerListener oca) {
        v.findViewById(R.id.cancel).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View p1) {
                    a.dismiss();
                }
            });
        v.findViewById(R.id.save).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View p1) {
                JSONObject jo=new JSONObject();
                try {
                    int position1 = pLogo.getSelectedItemPosition();
                    String[] list = c.getAssets().list("networks");
                    jo.put("FLAG", list[position1].replace("icon_","").replace(".png",""));
                    jo.put("proto_spin", sslmethod.getSelectedItemPosition()+3);
                    jo.put("server_type", mServerType());
                    jo.put("Name", etSSLName.getText().toString());
                    jo.put("SSLSNI", FileUtil.hideJs(c,etSSLSNI.getText().toString()));
                    jo.put("SSLPayload", FileUtil.hideJs(c,etSSLPayload.getText().toString()));
                    jo.put("Info", etSSLInfo.getText().toString());
                    jo.put("UseDefProxy", ckUseDefProxy.isChecked());
                    jo.put("SquidProxy", FileUtil.hideJs(c,etSquidProxy.getText().toString()));
                    jo.put("SquidPort", etSquidPort.getText().toString());
                    jo.put("SSLPort", etSSLPort.getText().toString());
                    oca.onAdd(jo);
                    Toast.makeText(c, etSSLName.getText().toString()+" add", Toast.LENGTH_SHORT).show();
                    if(!isAdd)a.dismiss();
                } catch (Exception e) {
                    Toast.makeText(c, e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public void init() {
        a.show();
    }
}
