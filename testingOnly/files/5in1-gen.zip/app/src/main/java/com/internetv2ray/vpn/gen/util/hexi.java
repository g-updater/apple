package com.internetv2ray.vpn.gen.util;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.internetv2ray.vpn.gen.MainActivity;
import com.internetv2ray.vpn.gen.R;


public class hexi extends AppCompatActivity {
    private Toolbar tb;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.d_dialog);

        Button encryptBtn, decryptBtn;
        encryptBtn = findViewById(R.id.encryptBtn);
        decryptBtn = findViewById(R.id.decryptBtn);

        EditText encryptET, decryptET;
        encryptET = findViewById(R.id.encryptET);
        decryptET = findViewById(R.id.decryptET);

        encryptBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {



                String encryptedText = BED.En(encryptET.getText().toString(),FileUtil.tostring(BED.a));

                decryptET.setText(encryptedText);
            }
        });

        decryptBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                  //  String decryptedText = BED.De(decryptET.getText().toString(), FileUtil.tostring(BED.a));FileUtil.tostring(BED.a);
                    String ms = decryptET.getText().toString().trim();
                    String de = FileUtil.showJs(hexi.this, ms);
                    en_de_text(ms, de);
                  //  encryptET.setText(decryptedText);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
    private void en_de_text(String m, String r){
        LayoutInflater inflater = LayoutInflater.from(hexi.this);
        final View view = inflater.inflate(R.layout.en_de, null);
        AlertDialog.Builder certDialog = new AlertDialog.Builder(this);
        certDialog.setView(view);
        certDialog.setTitle("Encrypt/Decrypt");
        certDialog.setIcon(R.drawable.icon7);
        certDialog.setCancelable(false);
        final EditText msg = view.findViewById(R.id.text_message);
        final TextView result = view.findViewById(R.id.result_message);
        msg.setText(m);
        result.setText(r);
        certDialog.setNeutralButton("Close", new DialogInterface.OnClickListener(){
            @Override
            public void onClick(DialogInterface p1, int p2) {
                p1.dismiss();
            }
        });
        certDialog.setNegativeButton("Encrypt",  new DialogInterface.OnClickListener(){
            @Override
            public void onClick(DialogInterface p1, int p2) {
                String ms = msg.getText().toString().trim();
                String en = FileUtil.hideJs(hexi.this, ms);
                en_de_text(ms, en);
            }
        });
        certDialog.setPositiveButton("Decrypt", new DialogInterface.OnClickListener(){
            @Override
            public void onClick(DialogInterface p1, int p2) {
                String ms = msg.getText().toString().trim();
                String de = FileUtil.showJs(hexi.this, ms);
                en_de_text(ms, de);
            }
        });
        AlertDialog cDialog = certDialog.create();
        cDialog.show();
    }
}