package com.internetv2ray.vpn.gen;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.TextView;

public class Errors extends AppCompatActivity {
	
    TextView error;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
		setContentView(R.layout.errors);
		error = (TextView) findViewById(R.id.errors);
        
        error.setText(getIntent().getStringExtra("error"));
    }
}






