package com.internetv2ray.vpn.gen.util;

import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import static android.content.DialogInterface.BUTTON_POSITIVE;
import android.widget.RadioGroup;

import androidx.appcompat.app.AlertDialog;

import com.internetv2ray.vpn.gen.R;

public class gen {

    private RadioGroup A;
    private RadioButton B;
    private Spinner C;
    private Spinner D;
    private EditText E;
    private Spinner F;
    private CheckBox o;
    private CheckBox p;
    private CheckBox q;
    private CheckBox r;
    private CheckBox s;
    private CheckBox t;
    private CheckBox u;
    private CheckBox vj;
    private CheckBox w;
    private CheckBox x;
    private CheckBox y;
    private static Context context;
    private static View view;
    private static SharedPreferences mPref;
    private static LayoutInflater inflater;
    private View sshView;
    private OnGenerateListener generateListener;
    private OnCancelListener cancelListener;
    private OnNeutralListener neutralButtonListener;
    private CharSequence generateButtonName;
    private CharSequence cancelButtonName;
    private CharSequence neutralButtonName;
    private String title;
    private int mIcon = 0;
    public AlertDialog.Builder adb;

    public gen(Context context) {
        this.context = context;
        adb = new AlertDialog.Builder(context);
    }

    /** interface for positive button **/
    public interface OnGenerateListener{
        void onGenerate(String payloadGenerated);
    }

    /** interface for negative button **/
    public interface OnCancelListener {
        void onCancelListener();
    }

    /** interface for neutral button **/
    public interface OnNeutralListener {
        void onNeutralListener();
    }

    /**
     * This should not be null
     * This serves as your positive button
     **/
    public void setGenerateListener(CharSequence generateButtonName, OnGenerateListener generateListener) {
        this.generateButtonName = generateButtonName;
        this.generateListener = generateListener;
    }

    /**
     * This should not be null
     * This serves as your negative button
     **/
    public void setCancelListener(CharSequence cancelButtonName, OnCancelListener cancelListener) {
        this.cancelButtonName = cancelButtonName;
        this.cancelListener = cancelListener;
    }

    /**
     * This should not be null
     * This serves as your neutral button
     **/
    public void setNeutralButtonListener(CharSequence neutralButtonName, OnNeutralListener neutralButtonListener) {
        this.neutralButtonName = neutralButtonName;
        this.neutralButtonListener = neutralButtonListener;
    }


    public void setDialogTitle(String title) {
        this.title = title;
    }

    public void setDialogIcon(int icon) {
        this.mIcon = icon;
    }

    public void show() {
        adb.setCancelable(false);
        adb.setView(generatorView());
        if (mIcon != 0) {
            adb.setIcon(mIcon);
        }
        if (title != null) {
            adb.setTitle(title);
        }
        adb.setView(generatorView());
        if (generateListener != null) {
            adb.setPositiveButton(generateButtonName, generate);
        }
        adb.setNegativeButton("Cancel",null);
        if (neutralButtonListener != null) {
            adb.setNeutralButton(neutralButtonName, neutral);
        }
        AlertDialog alertDialog = adb.create();
        alertDialog.show();
    }

    public void close(){
        adb.create().dismiss();
    }

    private DialogInterface.OnClickListener generate = new DialogInterface.OnClickListener() {
        private String b;
        private String I;
        @Override
        public void onClick(DialogInterface dialogInterface, int in) {
            switch (in) {
                case BUTTON_POSITIVE:
                    I = B.getText().toString();
                    StringBuilder stringBuilder = new StringBuilder();
                    String obj = D.getSelectedItem().toString();
                    String obj2 = C.getSelectedItem().toString();
                    String replace = E.getText().toString().replace("http://", "").replace("https://", "");
                    if (x.isChecked()) {
                        replace = "[rotation=" + replace + "]";
                    }
                    StringBuilder stringBuilder2 = new StringBuilder();
                    if (o.isChecked()) {
                        stringBuilder2.append(replace + "@");
                    }
                    stringBuilder2.append("[host_port]");
                    if (p.isChecked()) {
                        stringBuilder2.append("@" + replace);
                    }
                    String stringBuilder3 = stringBuilder2.toString();
                    String str = "";
                    if (I.equals("SPLIT")) {
                        str = y.isChecked() ? obj.equals("Back Inject") ? "[crlf][splitNoDelay]" : "[splitNoDelay]" : obj.equals("Back Inject") ? "[crlf][split]" : "[split]";
                    }
                    if (obj.equals("Front Inject")) {
                        stringBuilder.append(obj2 + " http://" + replace + "/ HTTP/1.1[crlf]");
                    } else if (obj.equals("Back Inject")) {
                        stringBuilder.append("CONNECT " + stringBuilder3 + " HTTP/1.1[crlf][crlf]" + str + obj2 + " http://" + replace + "/ [protocol][crlf]");
                    } else if (!vj.isChecked()) {
                        stringBuilder.append(obj2 + " " + stringBuilder3 + " [protocol][crlf]");
                    } else if (obj.equals("Back Inject") || o.isChecked() || p.isChecked()) {
                        stringBuilder.append(obj2 + " " + stringBuilder3 + " [protocol][crlf]");
                    } else {
                        stringBuilder.append("[netData][crlf]");
                    }
                    stringBuilder.append("Host: " + replace + "[crlf]");
                    if (q.isChecked()) {
                        stringBuilder.append("X-Online-Host: " + replace + "[crlf]");
                    }
                    if (s.isChecked()) {
                        stringBuilder.append("X-Forward-Host: " + replace + "[crlf]");
                    }
                    if (r.isChecked()) {
                        stringBuilder.append("X-Forwarded-For: " + replace + "[crlf]");
                    }
                    if (t.isChecked()) {
                        stringBuilder.append("Connection: Keep-Alive[crlf]");
                    }
                    if (u.isChecked()) {
                        this.b = F.getSelectedItem().toString();
                        if (this.b.equals("Firefox")) {
                            stringBuilder.append("User-Agent: Mozilla/5.0 (Android; Mobile; rv:35.0) Gecko/35.0 Firefox/35.0\r\n");
                        } else if (this.b.equals("Chrome")) {
                            stringBuilder.append("User-Agent: Mozilla/5.0 (Linux; Android 4.4.2; SAMSUNG-SM-T537A Build/KOT49H) AppleWebKit/537.36 (KHTML like Gecko) Chrome/35.0.1916.141 Safari/537.36[crlf]");
                        } else if (this.b.equals("Opera Mini")) {
                            stringBuilder.append("User-Agent: Mozilla/5.0 (Linux; Android 5.1.1; Nexus 7 Build/LMY47V) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.78 Safari/537.36 OPR/30.0.1856.93524[crlf]");
                        } else if (this.b.equals("Puffin")) {
                            stringBuilder.append("User-Agent: Mozilla/5.0 (X11; U; Linux x86_64; en-gb) AppleWebKit/534.35 (KHTML, like Gecko) Chrome/11.0.696.65 Safari/534.35 Puffin/2.9174AP[crlf]");
                        } else if (this.b.equals("Safari")) {
                            stringBuilder.append("User-Agent: Mozilla/5.0 (Linux; U; Android 2.0; en-us; Droid Build/ESD20) AppleWebKit/530.17 (KHTML, like Gecko) Version/4.0 Mobile Safari/530.17[crlf]");
                        } else if (this.b.equals("UCBrowser")) {
                            stringBuilder.append("User-Agent: Mozilla/5.0 (Linux; U; Android 2.3.3; en-us ; LS670 Build/GRI40) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1/UCBrowser/8.6.1.262/145/355[crlf]");
                        } else if (this.b.equals("Default")) {
                            stringBuilder.append("User-Agent: [ua][crlf]");
                        }
                    }
                    if (w.isChecked()) {
                        stringBuilder.append("CONNECT [host_port] [protocol][crlf]");
                    }
                    stringBuilder.append("[crlf]");
                    if (obj.equals("Front Inject")) {
                        if (!vj.isChecked()) {
                            stringBuilder.append(str + "CONNECT " + stringBuilder3 + " [protocol][crlf][crlf]");
                        } else if (o.isChecked() || p.isChecked()) {
                            stringBuilder.append(str + "CONNECT " + stringBuilder3 + " [protocol][crlf][crlf]");
                        } else {
                            stringBuilder.append(str + "[netData][crlf][crlf]");
                        }
                    }
                    mPref.edit().putString("xHost", E.getText().toString()).commit();
                    mPref.edit().putBoolean("xFrontQuery", o.isChecked()).commit();
                    mPref.edit().putBoolean("xBackQuery", p.isChecked()).commit();
                    mPref.edit().putBoolean("xOnlineHost", q.isChecked()).commit();
                    mPref.edit().putBoolean("xForwardedFor", r.isChecked()).commit();
                    mPref.edit().putBoolean("xForwardHost", s.isChecked()).commit();
                    mPref.edit().putBoolean("xKeepAlive", t.isChecked()).commit();
                    mPref.edit().putBoolean("xUserAgent", u.isChecked()).commit();
                    mPref.edit().putBoolean("xRealRequest", vj.isChecked()).commit();
                    mPref.edit().putBoolean("xDualConnect", w.isChecked()).commit();
                    mPref.edit().putBoolean("xRotation", x.isChecked()).commit();
                    mPref.edit().putBoolean("xSplitNoDelay", y.isChecked()).commit();
                    mPref.edit().putInt("xRadioGroup", A.getCheckedRadioButtonId()).commit();
                    mPref.edit().putInt("RequestMethod", C.getSelectedItemPosition()).commit();
                    mPref.edit().putInt("InjectMethod", D.getSelectedItemPosition()).commit();
                    mPref.edit().putInt("UserAgent", F.getSelectedItemPosition()).commit();
                    generateListener.onGenerate(stringBuilder.toString());
            }
        }
    };

    private DialogInterface.OnClickListener cancel = new DialogInterface.OnClickListener(){

        @Override
        public void onClick(DialogInterface p1, int p2)
        {
            // TODO: Implement this method
            if(cancelListener != null){
                cancelListener.onCancelListener();
            }

        }
    };

    private DialogInterface.OnClickListener neutral = new DialogInterface.OnClickListener(){

        @Override
        public void onClick(DialogInterface p1, int p2)
        {
            // TODO: Implement this method
            if(neutralButtonListener != null){
                neutralButtonListener.onNeutralListener();
            }

        }
    };

    private View generatorView(){
        inflater = LayoutInflater.from(context);
        view = inflater.inflate(R.layout.h_gen, null);
        mPref = context.getSharedPreferences("TKApplication", context.MODE_PRIVATE);
        this.sshView = view.findViewById(R.id.SSHcrollView);
        this.E = view.findViewById(R.id.editTextInjectUrl);
        E.setText(mPref.getString("xHost", ""));
        this.C = view.findViewById(R.id.spinnerRequestMethod);
        C.setSelection(mPref.getInt("RequestMethod", 0));
        this.D = view.findViewById(R.id.spinnerInjectMethod);
        D.setSelection(mPref.getInt("InjectMethod", 0));
        this.o = view.findViewById(R.id.checkBoxFrontQuery);
        o.setChecked(mPref.getBoolean("xFrontQuery", false));
        this.p = view.findViewById(R.id.checkBoxBackQuery);
        p.setChecked(mPref.getBoolean("xBackQuery", false));
        this.q = view.findViewById(R.id.checkBoxOnlineHost);
        q.setChecked(mPref.getBoolean("xOnlineHost", false));
        this.r = view.findViewById(R.id.checkBoxForwardedFor);
        r.setChecked(mPref.getBoolean("xForwardedFor", false));
        this.s = view.findViewById(R.id.checkBoxForwardHost);
        s.setChecked(mPref.getBoolean("xForwardHost", false));
        this.t = view.findViewById(R.id.checkBoxKeepAlive);
        t.setChecked(mPref.getBoolean("xKeepAlive", false));
        this.u = view.findViewById(R.id.checkBoxUserAgent);
        u.setChecked(mPref.getBoolean("xUserAgent", false));
        this.F = view.findViewById(R.id.spinner2);
        F.setSelection(mPref.getInt("UserAgent", 0));
        this.vj = view.findViewById(R.id.checkBoxRealRequest);
        vj.setChecked(mPref.getBoolean("xRealRequest", false));
        this.w = view.findViewById(R.id.checkBoxDualConnect);
        w.setChecked(mPref.getBoolean("xDualConnect", false));
        this.A = view.findViewById(R.id.radio1);
        this.B = view.findViewById(A.getCheckedRadioButtonId());
        this.x = view.findViewById(R.id.rotationMethodCheckbox);
        this.y = view.findViewById(R.id.splitNoDelayCheckbox);
        this.F.setEnabled(false);
        this.o.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View p1) {
                    p.setChecked(false);
                }
            });
        this.p.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View p1) {
                    o.setChecked(false);
                }
            });
        this.u.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View p1) {
                    if (F.isEnabled()) {
                        F.setEnabled(false);
                    } else {
                        F.setEnabled(true);
                    }
                }
            });
        A.check(mPref.getInt("xRadioGroup", R.id.radioMerger));
        A.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                public final void onCheckedChanged(RadioGroup radioGroup, int i) {
                    B = (RadioButton) A.findViewById(i);
                    if (A.indexOfChild(B) == 1) {
                        y.setEnabled(true);
                        y.setChecked(mPref.getBoolean("xSplitNoDelay", false));
                        return;
                    }
                    y.setEnabled(false);
                    y.setChecked(false);
                }
            });
        x.setChecked(mPref.getBoolean("xRotation", false));
        this.x.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                public final void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                    if (z) {
                        E.setHint("ex. bug1.com;bug2.com");
                    } else {
                        E.setHint("ex. bug.com");
                    }
                }
            });
        return view;
    }

}
